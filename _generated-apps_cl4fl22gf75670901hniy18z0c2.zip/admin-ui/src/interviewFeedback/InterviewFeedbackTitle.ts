import { InterviewFeedback as TInterviewFeedback } from "../api/interviewFeedback/InterviewFeedback";

export const INTERVIEWFEEDBACK_TITLE_FIELD = "feedback";

export const InterviewFeedbackTitle = (record: TInterviewFeedback): string => {
  return record.feedback || record.id;
};
