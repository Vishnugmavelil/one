import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  ReferenceField,
  TextField,
  DateField,
} from "react-admin";
import Pagination from "../Components/Pagination";
import { CANDIDATEFEEDBACK_TITLE_FIELD } from "../candidateFeedback/CandidateFeedbackTitle";
import { FEEDBACKSKILL_TITLE_FIELD } from "../feedbackSkill/FeedbackSkillTitle";
import { EMPLOYEE_TITLE_FIELD } from "../employee/EmployeeTitle";

export const InterviewFeedbackList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"interview_feedbacks"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <ReferenceField
          label="candidate_feedbacks"
          source="candidatefeedback.id"
          reference="CandidateFeedback"
        >
          <TextField source={CANDIDATEFEEDBACK_TITLE_FIELD} />
        </ReferenceField>
        <DateField source="createdAt" label="Created At" />
        <TextField label="date" source="date" />
        <TextField label="feedback" source="feedback" />
        <ReferenceField
          label="feedback_skills"
          source="feedbackskill.id"
          reference="FeedbackSkill"
        >
          <TextField source={FEEDBACKSKILL_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="ID" source="id" />
        <ReferenceField
          label="interviewer"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
