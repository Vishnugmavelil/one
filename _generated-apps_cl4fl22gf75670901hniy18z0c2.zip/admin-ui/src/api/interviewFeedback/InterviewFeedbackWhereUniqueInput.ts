export type InterviewFeedbackWhereUniqueInput = {
  id: string;
};
