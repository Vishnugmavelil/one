import { CandidateFeedback } from "../candidateFeedback/CandidateFeedback";
import { FeedbackSkill } from "../feedbackSkill/FeedbackSkill";
import { Employee } from "../employee/Employee";

export type InterviewFeedback = {
  candidateFeedbacks?: CandidateFeedback;
  createdAt: Date;
  date: Date;
  feedback: string | null;
  feedbackSkills?: FeedbackSkill;
  id: string;
  interviewer?: Employee;
  updatedAt: Date;
};
