import { CandidateFeedbackWhereUniqueInput } from "../candidateFeedback/CandidateFeedbackWhereUniqueInput";
import { DateTimeFilter } from "../../util/DateTimeFilter";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { FeedbackSkillWhereUniqueInput } from "../feedbackSkill/FeedbackSkillWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";

export type InterviewFeedbackWhereInput = {
  candidateFeedbacks?: CandidateFeedbackWhereUniqueInput;
  date?: DateTimeFilter;
  feedback?: StringNullableFilter;
  feedbackSkills?: FeedbackSkillWhereUniqueInput;
  id?: StringFilter;
  interviewer?: EmployeeWhereUniqueInput;
};
