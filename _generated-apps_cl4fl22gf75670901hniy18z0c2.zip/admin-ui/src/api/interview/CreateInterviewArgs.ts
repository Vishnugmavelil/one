import { InterviewCreateInput } from "./InterviewCreateInput";

export type CreateInterviewArgs = {
  data: InterviewCreateInput;
};
