import { SkillSetWhereInput } from "./SkillSetWhereInput";

export type SkillSetListRelationFilter = {
  every?: SkillSetWhereInput;
  some?: SkillSetWhereInput;
  none?: SkillSetWhereInput;
};
