import { SkillSetWhereUniqueInput } from "./SkillSetWhereUniqueInput";

export type SkillSetFindUniqueArgs = {
  where: SkillSetWhereUniqueInput;
};
