import { SkillSetCreateInput } from "./SkillSetCreateInput";

export type CreateSkillSetArgs = {
  data: SkillSetCreateInput;
};
