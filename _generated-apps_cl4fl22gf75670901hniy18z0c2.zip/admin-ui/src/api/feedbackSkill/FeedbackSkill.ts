import { InterviewFeedback } from "../interviewFeedback/InterviewFeedback";
import { SkillSet } from "../skillSet/SkillSet";

export type FeedbackSkill = {
  createdAt: Date;
  feedbackId?: InterviewFeedback;
  id: string;
  skillId?: SkillSet;
  updatedAt: Date;
};
