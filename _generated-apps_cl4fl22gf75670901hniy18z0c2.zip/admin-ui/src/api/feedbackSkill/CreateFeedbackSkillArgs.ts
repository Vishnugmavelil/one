import { FeedbackSkillCreateInput } from "./FeedbackSkillCreateInput";

export type CreateFeedbackSkillArgs = {
  data: FeedbackSkillCreateInput;
};
