import { SortOrder } from "../../util/SortOrder";

export type FeedbackSkillOrderByInput = {
  createdAt?: SortOrder;
  feedbackIdId?: SortOrder;
  id?: SortOrder;
  skillIdId?: SortOrder;
  updatedAt?: SortOrder;
};
