import { FeedbackSkillWhereUniqueInput } from "./FeedbackSkillWhereUniqueInput";
import { FeedbackSkillUpdateInput } from "./FeedbackSkillUpdateInput";

export type UpdateFeedbackSkillArgs = {
  where: FeedbackSkillWhereUniqueInput;
  data: FeedbackSkillUpdateInput;
};
