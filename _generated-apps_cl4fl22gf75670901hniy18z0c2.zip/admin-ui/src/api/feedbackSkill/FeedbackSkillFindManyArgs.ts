import { FeedbackSkillWhereInput } from "./FeedbackSkillWhereInput";
import { FeedbackSkillOrderByInput } from "./FeedbackSkillOrderByInput";

export type FeedbackSkillFindManyArgs = {
  where?: FeedbackSkillWhereInput;
  orderBy?: Array<FeedbackSkillOrderByInput>;
  skip?: number;
  take?: number;
};
