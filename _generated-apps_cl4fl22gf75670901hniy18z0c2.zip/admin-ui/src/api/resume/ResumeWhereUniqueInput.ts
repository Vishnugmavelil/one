export type ResumeWhereUniqueInput = {
  id: string;
};
