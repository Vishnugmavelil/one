import { Candidate } from "../candidate/Candidate";
import { EmployeeResume } from "../employeeResume/EmployeeResume";

export type Resume = {
  candidates?: Candidate;
  comment: string | null;
  createdAt: Date;
  document: string;
  employeeResumes?: EmployeeResume;
  id: string;
  updatedAt: Date;
};
