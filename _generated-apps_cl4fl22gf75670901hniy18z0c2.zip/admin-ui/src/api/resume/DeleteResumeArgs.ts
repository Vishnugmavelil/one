import { ResumeWhereUniqueInput } from "./ResumeWhereUniqueInput";

export type DeleteResumeArgs = {
  where: ResumeWhereUniqueInput;
};
