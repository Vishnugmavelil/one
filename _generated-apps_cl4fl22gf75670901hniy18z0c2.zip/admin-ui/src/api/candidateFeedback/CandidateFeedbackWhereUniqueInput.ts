export type CandidateFeedbackWhereUniqueInput = {
  id: string;
};
