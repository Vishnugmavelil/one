import { Candidate } from "../candidate/Candidate";
import { InterviewFeedback } from "../interviewFeedback/InterviewFeedback";

export type CandidateFeedback = {
  candidate_id?: Candidate;
  createdAt: Date;
  feedback_id?: InterviewFeedback;
  id: string;
  updatedAt: Date;
};
