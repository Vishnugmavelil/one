import { CandidateFeedbackWhereUniqueInput } from "./CandidateFeedbackWhereUniqueInput";

export type CandidateFeedbackFindUniqueArgs = {
  where: CandidateFeedbackWhereUniqueInput;
};
