import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type CandidateSkillWhereInput = {
  candidateId?: CandidateWhereUniqueInput;
  id?: StringFilter;
  skill_id?: SkillSetWhereUniqueInput;
};
