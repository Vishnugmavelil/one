import { CandidateSkillWhereUniqueInput } from "./CandidateSkillWhereUniqueInput";

export type CandidateSkillFindUniqueArgs = {
  where: CandidateSkillWhereUniqueInput;
};
