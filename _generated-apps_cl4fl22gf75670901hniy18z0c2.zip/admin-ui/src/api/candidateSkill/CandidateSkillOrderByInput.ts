import { SortOrder } from "../../util/SortOrder";

export type CandidateSkillOrderByInput = {
  candidateIdId?: SortOrder;
  createdAt?: SortOrder;
  id?: SortOrder;
  skill_idId?: SortOrder;
  updatedAt?: SortOrder;
};
