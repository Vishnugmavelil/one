export type EmployeeResumeWhereUniqueInput = {
  id: string;
};
