import { EmployeeResumeWhereUniqueInput } from "./EmployeeResumeWhereUniqueInput";

export type DeleteEmployeeResumeArgs = {
  where: EmployeeResumeWhereUniqueInput;
};
