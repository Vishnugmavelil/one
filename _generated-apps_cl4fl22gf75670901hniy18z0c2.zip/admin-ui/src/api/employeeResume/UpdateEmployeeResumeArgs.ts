import { EmployeeResumeWhereUniqueInput } from "./EmployeeResumeWhereUniqueInput";
import { EmployeeResumeUpdateInput } from "./EmployeeResumeUpdateInput";

export type UpdateEmployeeResumeArgs = {
  where: EmployeeResumeWhereUniqueInput;
  data: EmployeeResumeUpdateInput;
};
