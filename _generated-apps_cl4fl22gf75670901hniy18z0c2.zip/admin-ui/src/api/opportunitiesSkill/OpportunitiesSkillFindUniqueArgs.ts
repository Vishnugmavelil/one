import { OpportunitiesSkillWhereUniqueInput } from "./OpportunitiesSkillWhereUniqueInput";

export type OpportunitiesSkillFindUniqueArgs = {
  where: OpportunitiesSkillWhereUniqueInput;
};
