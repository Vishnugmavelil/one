export type OpportunitiesSkillWhereUniqueInput = {
  id: string;
};
