import { SortOrder } from "../../util/SortOrder";

export type OpportunitiesSkillOrderByInput = {
  createdAt?: SortOrder;
  id?: SortOrder;
  opportunities_idId?: SortOrder;
  skillIdId?: SortOrder;
  updatedAt?: SortOrder;
};
