import { StringFilter } from "../../util/StringFilter";
import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type OpportunitiesSkillWhereInput = {
  id?: StringFilter;
  opportunities_id?: OpportunityWhereUniqueInput;
  skillId?: SkillSetWhereUniqueInput;
};
