import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type OpportunitiesSkillCreateInput = {
  opportunities_id: OpportunityWhereUniqueInput;
  skillId: SkillSetWhereUniqueInput;
};
