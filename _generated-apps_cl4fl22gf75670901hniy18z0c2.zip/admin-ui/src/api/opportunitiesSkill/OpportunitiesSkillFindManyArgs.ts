import { OpportunitiesSkillWhereInput } from "./OpportunitiesSkillWhereInput";
import { OpportunitiesSkillOrderByInput } from "./OpportunitiesSkillOrderByInput";

export type OpportunitiesSkillFindManyArgs = {
  where?: OpportunitiesSkillWhereInput;
  orderBy?: Array<OpportunitiesSkillOrderByInput>;
  skip?: number;
  take?: number;
};
