import { Opportunity } from "../opportunity/Opportunity";
import { Employee } from "../employee/Employee";

export type Community = {
  communityId?: Opportunity;
  createdAt: Date;
  description: string | null;
  employees?: Employee;
  id: string;
  name: string;
  updatedAt: Date;
};
