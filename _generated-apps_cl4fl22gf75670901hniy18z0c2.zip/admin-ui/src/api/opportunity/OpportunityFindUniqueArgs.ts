import { OpportunityWhereUniqueInput } from "./OpportunityWhereUniqueInput";

export type OpportunityFindUniqueArgs = {
  where: OpportunityWhereUniqueInput;
};
