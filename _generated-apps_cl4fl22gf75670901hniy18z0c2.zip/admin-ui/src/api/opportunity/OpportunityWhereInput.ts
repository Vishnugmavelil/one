import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { IntFilter } from "../../util/IntFilter";
import { StringFilter } from "../../util/StringFilter";
import { OpportunitiesSkillWhereUniqueInput } from "../opportunitiesSkill/OpportunitiesSkillWhereUniqueInput";
import { DateTimeFilter } from "../../util/DateTimeFilter";
import { StringNullableFilter } from "../../util/StringNullableFilter";

export type OpportunityWhereInput = {
  AssignedCommunity?: CommunityWhereUniqueInput;
  ClaimedPerson?: EmployeeWhereUniqueInput;
  Experience_required?: IntFilter;
  firm?: StringFilter;
  id?: StringFilter;
  mappedPerson?: EmployeeWhereUniqueInput;
  opportunitiesSkills?: OpportunitiesSkillWhereUniqueInput;
  Required_close_date?: DateTimeFilter;
  Status?: StringNullableFilter;
};
