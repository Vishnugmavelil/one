import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";

export type DeleteCandidateArgs = {
  where: CandidateWhereUniqueInput;
};
