import { InterviewWhereUniqueInput } from "../interview/InterviewWhereUniqueInput";

export type InterviewCreateNestedManyWithoutCandidatesInput = {
  connect?: Array<InterviewWhereUniqueInput>;
};
