import * as React from "react";
import {
  Edit,
  SimpleForm,
  EditProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { EmployeeTitle } from "../employee/EmployeeTitle";
import { ResumeTitle } from "../resume/ResumeTitle";

export const EmployeeResumeEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="employee_id"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <ReferenceInput source="resume.id" reference="Resume" label="resume_id">
          <SelectInput optionText={ResumeTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Edit>
  );
};
