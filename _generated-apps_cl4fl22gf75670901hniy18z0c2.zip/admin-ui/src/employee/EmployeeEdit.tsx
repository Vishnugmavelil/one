import * as React from "react";

import {
  Edit,
  SimpleForm,
  EditProps,
  NumberInput,
  ReferenceInput,
  SelectInput,
  TextInput,
  DateInput,
  ReferenceArrayInput,
  SelectArrayInput,
} from "react-admin";

import { EmployeeTitle } from "./EmployeeTitle";
import { CommunityTitle } from "../community/CommunityTitle";
import { EmployeeResumeTitle } from "../employeeResume/EmployeeResumeTitle";
import { InterviewTitle } from "../interview/InterviewTitle";
import { InterviewFeedbackTitle } from "../interviewFeedback/InterviewFeedbackTitle";
import { OpportunityTitle } from "../opportunity/OpportunityTitle";

export const EmployeeEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <NumberInput step={1} label="Aadhar" source="Aadhar" />
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="address"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <TextInput label="Blood_Group" source="Blood_Group" />
        <DateInput label="career_start_date" source="career_start_date" />
        <ReferenceInput
          source="community.id"
          reference="Community"
          label="Community"
        >
          <SelectInput optionText={CommunityTitle} />
        </ReferenceInput>
        <NumberInput step={1} label="Contact_Number" source="contactNumber" />
        <DateInput label="date_of_joining" source="date_of_joining" />
        <DateInput label="dob" source="dob" />
        <TextInput label="email" source="email" type="email" />
        <NumberInput
          step={1}
          label="Emergency_Contact_Number"
          source="Emergency_Contact_Number"
        />
        <ReferenceInput
          source="employeeresume.id"
          reference="EmployeeResume"
          label="employee_resumes"
        >
          <SelectInput optionText={EmployeeResumeTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="employees_designation"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="employees_image"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <NumberInput label="fw_experience" source="fw_experience" />
        <TextInput label="gender" source="gender" />
        <ReferenceInput
          source="interview.id"
          reference="Interview"
          label="hr_employee_id"
        >
          <SelectInput optionText={InterviewTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="interviewfeedback.id"
          reference="InterviewFeedback"
          label="interview_feedbacks"
        >
          <SelectInput optionText={InterviewFeedbackTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="interview.id"
          reference="Interview"
          label="interviews_empoyee_id"
        >
          <SelectInput optionText={InterviewTitle} />
        </ReferenceInput>
        <ReferenceArrayInput
          source="mappedPerson"
          reference="Opportunity"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={OpportunityTitle} />
        </ReferenceArrayInput>
        <TextInput label="name" source="name" />
        <ReferenceInput
          source="opportunity.id"
          reference="Opportunity"
          label="opportunities"
        >
          <SelectInput optionText={OpportunityTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="PAN_Number"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <TextInput
          label="Personal_Mail_ID"
          source="Personal_Mail_ID"
          type="email"
        />
        <ReferenceInput
          source="interview.id"
          reference="Interview"
          label="recruiter_employer_id"
        >
          <SelectInput optionText={InterviewTitle} />
        </ReferenceInput>
        <NumberInput label="total_experience" source="total_experience" />
      </SimpleForm>
    </Edit>
  );
};
