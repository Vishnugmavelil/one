import * as React from "react";
import {
  Edit,
  SimpleForm,
  EditProps,
  ReferenceInput,
  SelectInput,
  TextInput,
} from "react-admin";
import { CandidateSkillTitle } from "../candidateSkill/CandidateSkillTitle";
import { FeedbackSkillTitle } from "../feedbackSkill/FeedbackSkillTitle";
import { OpportunitiesSkillTitle } from "../opportunitiesSkill/OpportunitiesSkillTitle";

export const SkillSetEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <ReferenceInput
          source="candidateskill.id"
          reference="CandidateSkill"
          label="candidate_skills"
        >
          <SelectInput optionText={CandidateSkillTitle} />
        </ReferenceInput>
        <TextInput label="comments" multiline source="comments" />
        <TextInput label="expertise_level" source="expertise_level" />
        <ReferenceInput
          source="feedbackskill.id"
          reference="FeedbackSkill"
          label="feedback_skills"
        >
          <SelectInput optionText={FeedbackSkillTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="opportunitiesskill.id"
          reference="OpportunitiesSkill"
          label="opportunities_skills"
        >
          <SelectInput optionText={OpportunitiesSkillTitle} />
        </ReferenceInput>
        <TextInput label="skill_name" source="skill_name" />
      </SimpleForm>
    </Edit>
  );
};
