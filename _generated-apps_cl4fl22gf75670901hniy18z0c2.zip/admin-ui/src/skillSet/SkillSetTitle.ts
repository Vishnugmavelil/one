import { SkillSet as TSkillSet } from "../api/skillSet/SkillSet";

export const SKILLSET_TITLE_FIELD = "skill_name";

export const SkillSetTitle = (record: TSkillSet): string => {
  return record.skill_name || record.id;
};
