import * as React from "react";
import {
  Edit,
  SimpleForm,
  EditProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { OpportunityTitle } from "../opportunity/OpportunityTitle";
import { SkillSetTitle } from "../skillSet/SkillSetTitle";

export const OpportunitiesSkillEdit = (
  props: EditProps
): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <ReferenceInput
          source="opportunity.id"
          reference="Opportunity"
          label="opportunities_id"
        >
          <SelectInput optionText={OpportunityTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="skillset.id"
          reference="SkillSet"
          label="skill_id"
        >
          <SelectInput optionText={SkillSetTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Edit>
  );
};
