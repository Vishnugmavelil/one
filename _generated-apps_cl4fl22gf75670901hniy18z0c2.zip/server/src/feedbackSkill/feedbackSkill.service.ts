import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { FeedbackSkillServiceBase } from "./base/feedbackSkill.service.base";

@Injectable()
export class FeedbackSkillService extends FeedbackSkillServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
