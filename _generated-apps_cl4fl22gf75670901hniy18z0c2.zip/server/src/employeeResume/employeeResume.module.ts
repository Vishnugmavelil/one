import { Module } from "@nestjs/common";
import { EmployeeResumeModuleBase } from "./base/employeeResume.module.base";
import { EmployeeResumeService } from "./employeeResume.service";
import { EmployeeResumeController } from "./employeeResume.controller";
import { EmployeeResumeResolver } from "./employeeResume.resolver";

@Module({
  imports: [EmployeeResumeModuleBase],
  controllers: [EmployeeResumeController],
  providers: [EmployeeResumeService, EmployeeResumeResolver],
  exports: [EmployeeResumeService],
})
export class EmployeeResumeModule {}
