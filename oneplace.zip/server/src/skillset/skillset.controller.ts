import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { SkillsetService } from "./skillset.service";
import { SkillsetControllerBase } from "./base/skillset.controller.base";

@swagger.ApiTags("skillsets")
@common.Controller("skillsets")
export class SkillsetController extends SkillsetControllerBase {
  constructor(
    protected readonly service: SkillsetService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
