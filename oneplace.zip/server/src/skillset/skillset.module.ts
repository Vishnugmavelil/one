import { Module } from "@nestjs/common";
import { SkillsetModuleBase } from "./base/skillset.module.base";
import { SkillsetService } from "./skillset.service";
import { SkillsetController } from "./skillset.controller";
import { SkillsetResolver } from "./skillset.resolver";

@Module({
  imports: [SkillsetModuleBase],
  controllers: [SkillsetController],
  providers: [SkillsetService, SkillsetResolver],
  exports: [SkillsetService],
})
export class SkillsetModule {}
