import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { SkillsetServiceBase } from "./base/skillset.service.base";

@Injectable()
export class SkillsetService extends SkillsetServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
