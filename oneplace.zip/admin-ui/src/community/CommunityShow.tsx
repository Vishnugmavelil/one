import * as React from "react";

import {
  Show,
  SimpleShowLayout,
  ShowProps,
  DateField,
  TextField,
  ReferenceManyField,
  Datagrid,
  ReferenceField,
} from "react-admin";

import { COMMUNITY_TITLE_FIELD } from "./CommunityTitle";
import { EMPLOYEE_TITLE_FIELD } from "../employee/EmployeeTitle";

export const CommunityShow = (props: ShowProps): React.ReactElement => {
  return (
    <Show {...props}>
      <SimpleShowLayout>
        <DateField source="createdAt" label="Created At" />
        <TextField label="description" source="description" />
        <TextField label="ID" source="id" />
        <TextField label="name" source="name" />
        <DateField source="updatedAt" label="Updated At" />
        <ReferenceManyField
          reference="Employee"
          target="CommunityId"
          label="employees"
        >
          <Datagrid rowClick="show">
            <TextField label="aadhar_number" source="aadharNumber" />
            <TextField label="address" source="address" />
            <TextField label="blood_group" source="bloodGroup" />
            <TextField label="career_start_date" source="careerStartDate" />
            <ReferenceField
              label="community"
              source="community.id"
              reference="Community"
            >
              <TextField source={COMMUNITY_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="contact_number" source="contactNumber" />
            <TextField label="course_out_date" source="courseOutDate" />
            <DateField source="createdAt" label="Created At" />
            <TextField label="date_of_joining" source="dateOfJoining" />
            <TextField label="designation" source="designation" />
            <TextField label="dob" source="dob" />
            <TextField label="email" source="email" />
            <TextField
              label="emergency_contact_number"
              source="emergencyContactNumber"
            />
            <TextField label="fw_experience" source="fwExperience" />
            <TextField label="gender" source="gender" />
            <TextField label="ID" source="id" />
            <TextField label="image" source="image" />
            <TextField label="name" source="name" />
            <TextField label="pan_number" source="panNumber" />
            <TextField label="personal_mail_id" source="personalMailId" />
            <TextField label="total_experience" source="totalExperience" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
        <ReferenceManyField
          reference="Opportunity"
          target="CommunityId"
          label="opportunities"
        >
          <Datagrid rowClick="show">
            <ReferenceField
              label="assigned_community"
              source="community.id"
              reference="Community"
            >
              <TextField source={COMMUNITY_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="claimed_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField
              label="experience_required"
              source="experienceRequired"
            />
            <TextField label="firm" source="firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="mapped_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="required_close_date" source="requiredCloseDate" />
            <TextField label="status" source="status" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
      </SimpleShowLayout>
    </Show>
  );
};
