import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";

export type CandidateCreateNestedManyWithoutSkillsetsInput = {
  connect?: Array<CandidateWhereUniqueInput>;
};
