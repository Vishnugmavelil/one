import { CandidateCreateNestedManyWithoutSkillsetsInput } from "./CandidateCreateNestedManyWithoutSkillsetsInput";
import { InterviewFeedbackCreateNestedManyWithoutSkillsetsInput } from "./InterviewFeedbackCreateNestedManyWithoutSkillsetsInput";
import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type SkillsetCreateInput = {
  candidates?: CandidateCreateNestedManyWithoutSkillsetsInput;
  expertiseLevel?: string | null;
  interviewFeedbacks?: InterviewFeedbackCreateNestedManyWithoutSkillsetsInput;
  opportunity?: OpportunityWhereUniqueInput | null;
  skillName?: string | null;
};
