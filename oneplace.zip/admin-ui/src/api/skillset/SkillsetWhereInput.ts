import { CandidateListRelationFilter } from "../candidate/CandidateListRelationFilter";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { InterviewFeedbackListRelationFilter } from "../interviewFeedback/InterviewFeedbackListRelationFilter";
import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type SkillsetWhereInput = {
  candidates?: CandidateListRelationFilter;
  expertiseLevel?: StringNullableFilter;
  id?: StringFilter;
  interviewFeedbacks?: InterviewFeedbackListRelationFilter;
  opportunity?: OpportunityWhereUniqueInput;
  skillName?: StringNullableFilter;
};
