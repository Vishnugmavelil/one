import { CandidateUpdateManyWithoutSkillsetsInput } from "./CandidateUpdateManyWithoutSkillsetsInput";
import { InterviewFeedbackUpdateManyWithoutSkillsetsInput } from "./InterviewFeedbackUpdateManyWithoutSkillsetsInput";
import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type SkillsetUpdateInput = {
  candidates?: CandidateUpdateManyWithoutSkillsetsInput;
  expertiseLevel?: string | null;
  interviewFeedbacks?: InterviewFeedbackUpdateManyWithoutSkillsetsInput;
  opportunity?: OpportunityWhereUniqueInput | null;
  skillName?: string | null;
};
