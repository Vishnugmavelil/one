import { SortOrder } from "../../util/SortOrder";

export type SkillsetOrderByInput = {
  createdAt?: SortOrder;
  expertiseLevel?: SortOrder;
  id?: SortOrder;
  opportunityId?: SortOrder;
  skillName?: SortOrder;
  updatedAt?: SortOrder;
};
