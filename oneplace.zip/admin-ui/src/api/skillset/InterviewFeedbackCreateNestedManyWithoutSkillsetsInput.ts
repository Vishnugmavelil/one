import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackCreateNestedManyWithoutSkillsetsInput = {
  connect?: Array<InterviewFeedbackWhereUniqueInput>;
};
