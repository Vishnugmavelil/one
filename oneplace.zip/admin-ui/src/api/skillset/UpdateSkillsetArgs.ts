import { SkillsetWhereUniqueInput } from "./SkillsetWhereUniqueInput";
import { SkillsetUpdateInput } from "./SkillsetUpdateInput";

export type UpdateSkillsetArgs = {
  where: SkillsetWhereUniqueInput;
  data: SkillsetUpdateInput;
};
