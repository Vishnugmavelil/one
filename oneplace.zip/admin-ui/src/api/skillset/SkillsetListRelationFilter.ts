import { SkillsetWhereInput } from "./SkillsetWhereInput";

export type SkillsetListRelationFilter = {
  every?: SkillsetWhereInput;
  some?: SkillsetWhereInput;
  none?: SkillsetWhereInput;
};
