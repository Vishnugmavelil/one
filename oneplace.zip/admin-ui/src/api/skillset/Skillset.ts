import { Candidate } from "../candidate/Candidate";
import { InterviewFeedback } from "../interviewFeedback/InterviewFeedback";
import { Opportunity } from "../opportunity/Opportunity";

export type Skillset = {
  candidates?: Array<Candidate>;
  createdAt: Date;
  expertiseLevel: string | null;
  id: string;
  interviewFeedbacks?: Array<InterviewFeedback>;
  opportunity?: Opportunity | null;
  skillName: string | null;
  updatedAt: Date;
};
