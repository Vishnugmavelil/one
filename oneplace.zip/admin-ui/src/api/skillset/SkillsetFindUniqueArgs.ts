import { SkillsetWhereUniqueInput } from "./SkillsetWhereUniqueInput";

export type SkillsetFindUniqueArgs = {
  where: SkillsetWhereUniqueInput;
};
