export type SkillsetWhereUniqueInput = {
  id: string;
};
