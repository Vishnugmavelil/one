import { SkillsetWhereInput } from "./SkillsetWhereInput";
import { SkillsetOrderByInput } from "./SkillsetOrderByInput";

export type SkillsetFindManyArgs = {
  where?: SkillsetWhereInput;
  orderBy?: Array<SkillsetOrderByInput>;
  skip?: number;
  take?: number;
};
