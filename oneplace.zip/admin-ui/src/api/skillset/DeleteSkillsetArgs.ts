import { SkillsetWhereUniqueInput } from "./SkillsetWhereUniqueInput";

export type DeleteSkillsetArgs = {
  where: SkillsetWhereUniqueInput;
};
