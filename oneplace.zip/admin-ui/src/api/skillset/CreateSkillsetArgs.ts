import { SkillsetCreateInput } from "./SkillsetCreateInput";

export type CreateSkillsetArgs = {
  data: SkillsetCreateInput;
};
