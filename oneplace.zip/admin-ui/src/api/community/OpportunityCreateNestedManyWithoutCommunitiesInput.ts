import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type OpportunityCreateNestedManyWithoutCommunitiesInput = {
  connect?: Array<OpportunityWhereUniqueInput>;
};
