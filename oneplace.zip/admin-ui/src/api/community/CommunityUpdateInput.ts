import { EmployeeUpdateManyWithoutCommunitiesInput } from "./EmployeeUpdateManyWithoutCommunitiesInput";
import { OpportunityUpdateManyWithoutCommunitiesInput } from "./OpportunityUpdateManyWithoutCommunitiesInput";

export type CommunityUpdateInput = {
  description?: string | null;
  employees?: EmployeeUpdateManyWithoutCommunitiesInput;
  name?: string | null;
  opportunities?: OpportunityUpdateManyWithoutCommunitiesInput;
};
