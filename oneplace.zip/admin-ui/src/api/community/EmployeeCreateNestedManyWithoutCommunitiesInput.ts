import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";

export type EmployeeCreateNestedManyWithoutCommunitiesInput = {
  connect?: Array<EmployeeWhereUniqueInput>;
};
