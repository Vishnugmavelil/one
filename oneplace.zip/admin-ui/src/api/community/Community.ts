import { Employee } from "../employee/Employee";
import { Opportunity } from "../opportunity/Opportunity";

export type Community = {
  createdAt: Date;
  description: string | null;
  employees?: Array<Employee>;
  id: string;
  name: string | null;
  opportunities?: Array<Opportunity>;
  updatedAt: Date;
};
