import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";

export type EmployeeUpdateManyWithoutCommunitiesInput = {
  connect?: Array<EmployeeWhereUniqueInput>;
  disconnect?: Array<EmployeeWhereUniqueInput>;
  set?: Array<EmployeeWhereUniqueInput>;
};
