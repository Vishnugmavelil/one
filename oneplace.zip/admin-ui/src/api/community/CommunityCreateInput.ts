import { EmployeeCreateNestedManyWithoutCommunitiesInput } from "./EmployeeCreateNestedManyWithoutCommunitiesInput";
import { OpportunityCreateNestedManyWithoutCommunitiesInput } from "./OpportunityCreateNestedManyWithoutCommunitiesInput";

export type CommunityCreateInput = {
  description?: string | null;
  employees?: EmployeeCreateNestedManyWithoutCommunitiesInput;
  name?: string | null;
  opportunities?: OpportunityCreateNestedManyWithoutCommunitiesInput;
};
