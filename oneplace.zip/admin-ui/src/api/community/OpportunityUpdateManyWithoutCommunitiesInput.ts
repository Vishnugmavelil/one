import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type OpportunityUpdateManyWithoutCommunitiesInput = {
  connect?: Array<OpportunityWhereUniqueInput>;
  disconnect?: Array<OpportunityWhereUniqueInput>;
  set?: Array<OpportunityWhereUniqueInput>;
};
