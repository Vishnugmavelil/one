import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackUpdateManyWithoutCandidatesInput = {
  connect?: Array<InterviewFeedbackWhereUniqueInput>;
  disconnect?: Array<InterviewFeedbackWhereUniqueInput>;
  set?: Array<InterviewFeedbackWhereUniqueInput>;
};
