import { CandidateCreateInput } from "./CandidateCreateInput";

export type CreateCandidateArgs = {
  data: CandidateCreateInput;
};
