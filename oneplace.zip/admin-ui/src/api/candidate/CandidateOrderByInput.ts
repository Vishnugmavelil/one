import { SortOrder } from "../../util/SortOrder";

export type CandidateOrderByInput = {
  additionalComments?: SortOrder;
  createdAt?: SortOrder;
  currentFirm?: SortOrder;
  currentStatus?: SortOrder;
  email?: SortOrder;
  id?: SortOrder;
  isOnNoticePeriod?: SortOrder;
  lastWorkingDay?: SortOrder;
  name?: SortOrder;
  noticePeriodTime?: SortOrder;
  updatedAt?: SortOrder;
};
