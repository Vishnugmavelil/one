import { InterviewFeedbackUpdateManyWithoutCandidatesInput } from "./InterviewFeedbackUpdateManyWithoutCandidatesInput";
import { SkillsetUpdateManyWithoutCandidatesInput } from "./SkillsetUpdateManyWithoutCandidatesInput";

export type CandidateUpdateInput = {
  additionalComments?: string | null;
  currentFirm?: string | null;
  currentStatus?: string | null;
  email?: string | null;
  interviewFeedback?: InterviewFeedbackUpdateManyWithoutCandidatesInput;
  isOnNoticePeriod?: boolean | null;
  lastWorkingDay?: Date | null;
  name?: string | null;
  noticePeriodTime?: number | null;
  skillset?: SkillsetUpdateManyWithoutCandidatesInput;
};
