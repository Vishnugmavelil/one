import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetUpdateManyWithoutCandidatesInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
  disconnect?: Array<SkillsetWhereUniqueInput>;
  set?: Array<SkillsetWhereUniqueInput>;
};
