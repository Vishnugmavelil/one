import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { InterviewFeedbackListRelationFilter } from "../interviewFeedback/InterviewFeedbackListRelationFilter";
import { BooleanNullableFilter } from "../../util/BooleanNullableFilter";
import { DateTimeNullableFilter } from "../../util/DateTimeNullableFilter";
import { IntNullableFilter } from "../../util/IntNullableFilter";
import { SkillsetListRelationFilter } from "../skillset/SkillsetListRelationFilter";

export type CandidateWhereInput = {
  additionalComments?: StringNullableFilter;
  currentFirm?: StringNullableFilter;
  currentStatus?: StringNullableFilter;
  email?: StringNullableFilter;
  id?: StringFilter;
  interviewFeedback?: InterviewFeedbackListRelationFilter;
  isOnNoticePeriod?: BooleanNullableFilter;
  lastWorkingDay?: DateTimeNullableFilter;
  name?: StringNullableFilter;
  noticePeriodTime?: IntNullableFilter;
  skillset?: SkillsetListRelationFilter;
};
