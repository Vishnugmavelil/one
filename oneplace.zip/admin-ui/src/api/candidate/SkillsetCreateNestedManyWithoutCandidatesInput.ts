import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetCreateNestedManyWithoutCandidatesInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
};
