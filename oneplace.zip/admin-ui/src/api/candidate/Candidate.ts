import { InterviewFeedback } from "../interviewFeedback/InterviewFeedback";
import { Skillset } from "../skillset/Skillset";

export type Candidate = {
  additionalComments: string | null;
  createdAt: Date;
  currentFirm: string | null;
  currentStatus: string | null;
  email: string | null;
  id: string;
  interviewFeedback?: Array<InterviewFeedback>;
  isOnNoticePeriod: boolean | null;
  lastWorkingDay: Date | null;
  name: string | null;
  noticePeriodTime: number | null;
  skillset?: Array<Skillset>;
  updatedAt: Date;
};
