import { InterviewFeedbackCreateNestedManyWithoutCandidatesInput } from "./InterviewFeedbackCreateNestedManyWithoutCandidatesInput";
import { SkillsetCreateNestedManyWithoutCandidatesInput } from "./SkillsetCreateNestedManyWithoutCandidatesInput";

export type CandidateCreateInput = {
  additionalComments?: string | null;
  currentFirm?: string | null;
  currentStatus?: string | null;
  email?: string | null;
  interviewFeedback?: InterviewFeedbackCreateNestedManyWithoutCandidatesInput;
  isOnNoticePeriod?: boolean | null;
  lastWorkingDay?: Date | null;
  name?: string | null;
  noticePeriodTime?: number | null;
  skillset?: SkillsetCreateNestedManyWithoutCandidatesInput;
};
