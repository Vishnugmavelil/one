import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackCreateNestedManyWithoutCandidatesInput = {
  connect?: Array<InterviewFeedbackWhereUniqueInput>;
};
