import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackCreateNestedManyWithoutEmployeesInput = {
  connect?: Array<InterviewFeedbackWhereUniqueInput>;
};
