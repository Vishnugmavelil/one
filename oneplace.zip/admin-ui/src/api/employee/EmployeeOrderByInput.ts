import { SortOrder } from "../../util/SortOrder";

export type EmployeeOrderByInput = {
  aadharNumber?: SortOrder;
  address?: SortOrder;
  bloodGroup?: SortOrder;
  careerStartDate?: SortOrder;
  communityId?: SortOrder;
  contactNumber?: SortOrder;
  courseOutDate?: SortOrder;
  createdAt?: SortOrder;
  dateOfJoining?: SortOrder;
  designation?: SortOrder;
  dob?: SortOrder;
  email?: SortOrder;
  emergencyContactNumber?: SortOrder;
  fwExperience?: SortOrder;
  gender?: SortOrder;
  id?: SortOrder;
  image?: SortOrder;
  name?: SortOrder;
  panNumber?: SortOrder;
  personalMailId?: SortOrder;
  totalExperience?: SortOrder;
  updatedAt?: SortOrder;
};
