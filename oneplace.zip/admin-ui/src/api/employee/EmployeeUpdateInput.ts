import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { InterviewFeedbackUpdateManyWithoutEmployeesInput } from "./InterviewFeedbackUpdateManyWithoutEmployeesInput";
import { OpportunityUpdateManyWithoutEmployeesInput } from "./OpportunityUpdateManyWithoutEmployeesInput";

export type EmployeeUpdateInput = {
  aadharNumber?: string | null;
  address?: string | null;
  bloodGroup?: string | null;
  careerStartDate?: Date | null;
  community?: CommunityWhereUniqueInput | null;
  contactNumber?: string | null;
  courseOutDate?: Date | null;
  dateOfJoining?: Date | null;
  designation?: string | null;
  dob?: Date | null;
  email?: string | null;
  emergencyContactNumber?: number | null;
  fwExperience?: number | null;
  gender?: string | null;
  image?: string | null;
  interviewFeedbacks?: InterviewFeedbackUpdateManyWithoutEmployeesInput;
  mappedOpportunity?: OpportunityUpdateManyWithoutEmployeesInput;
  name?: string | null;
  opportunities?: OpportunityUpdateManyWithoutEmployeesInput;
  panNumber?: string | null;
  personalMailId?: string | null;
  totalExperience?: number | null;
};
