import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { InterviewFeedbackCreateNestedManyWithoutEmployeesInput } from "./InterviewFeedbackCreateNestedManyWithoutEmployeesInput";
import { OpportunityCreateNestedManyWithoutEmployeesInput } from "./OpportunityCreateNestedManyWithoutEmployeesInput";

export type EmployeeCreateInput = {
  aadharNumber?: string | null;
  address?: string | null;
  bloodGroup?: string | null;
  careerStartDate?: Date | null;
  community?: CommunityWhereUniqueInput | null;
  contactNumber?: string | null;
  courseOutDate?: Date | null;
  dateOfJoining?: Date | null;
  designation?: string | null;
  dob?: Date | null;
  email?: string | null;
  emergencyContactNumber?: number | null;
  fwExperience?: number | null;
  gender?: string | null;
  image?: string | null;
  interviewFeedbacks?: InterviewFeedbackCreateNestedManyWithoutEmployeesInput;
  mappedOpportunity?: OpportunityCreateNestedManyWithoutEmployeesInput;
  name?: string | null;
  opportunities?: OpportunityCreateNestedManyWithoutEmployeesInput;
  panNumber?: string | null;
  personalMailId?: string | null;
  totalExperience?: number | null;
};
