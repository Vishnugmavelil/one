import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackUpdateManyWithoutEmployeesInput = {
  connect?: Array<InterviewFeedbackWhereUniqueInput>;
  disconnect?: Array<InterviewFeedbackWhereUniqueInput>;
  set?: Array<InterviewFeedbackWhereUniqueInput>;
};
