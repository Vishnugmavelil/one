import { Community } from "../community/Community";
import { Employee } from "../employee/Employee";
import { Skillset } from "../skillset/Skillset";

export type Opportunity = {
  assignedCommunity?: Community | null;
  claimedPerson?: Employee | null;
  createdAt: Date;
  experienceRequired: number | null;
  firm: string | null;
  id: string;
  mappedPerson?: Employee | null;
  requiredCloseDate: Date | null;
  skillsetNeeded?: Array<Skillset>;
  status: string | null;
  updatedAt: Date;
};
