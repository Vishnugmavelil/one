export type OpportunityWhereUniqueInput = {
  id: string;
};
