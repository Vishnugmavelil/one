import { OpportunityCreateInput } from "./OpportunityCreateInput";

export type CreateOpportunityArgs = {
  data: OpportunityCreateInput;
};
