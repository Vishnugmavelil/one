import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetUpdateManyWithoutOpportunitiesInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
  disconnect?: Array<SkillsetWhereUniqueInput>;
  set?: Array<SkillsetWhereUniqueInput>;
};
