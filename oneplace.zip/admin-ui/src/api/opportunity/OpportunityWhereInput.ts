import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { FloatNullableFilter } from "../../util/FloatNullableFilter";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { DateTimeNullableFilter } from "../../util/DateTimeNullableFilter";
import { SkillsetListRelationFilter } from "../skillset/SkillsetListRelationFilter";

export type OpportunityWhereInput = {
  assignedCommunity?: CommunityWhereUniqueInput;
  claimedPerson?: EmployeeWhereUniqueInput;
  experienceRequired?: FloatNullableFilter;
  firm?: StringNullableFilter;
  id?: StringFilter;
  mappedPerson?: EmployeeWhereUniqueInput;
  requiredCloseDate?: DateTimeNullableFilter;
  skillsetNeeded?: SkillsetListRelationFilter;
  status?: StringNullableFilter;
};
