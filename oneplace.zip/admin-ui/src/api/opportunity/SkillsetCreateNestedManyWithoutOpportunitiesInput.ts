import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetCreateNestedManyWithoutOpportunitiesInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
};
