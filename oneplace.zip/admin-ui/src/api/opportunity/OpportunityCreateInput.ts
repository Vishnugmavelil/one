import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { SkillsetCreateNestedManyWithoutOpportunitiesInput } from "./SkillsetCreateNestedManyWithoutOpportunitiesInput";

export type OpportunityCreateInput = {
  assignedCommunity?: CommunityWhereUniqueInput | null;
  claimedPerson?: EmployeeWhereUniqueInput | null;
  experienceRequired?: number | null;
  firm?: string | null;
  mappedPerson?: EmployeeWhereUniqueInput | null;
  requiredCloseDate?: Date | null;
  skillsetNeeded?: SkillsetCreateNestedManyWithoutOpportunitiesInput;
  status?: string | null;
};
