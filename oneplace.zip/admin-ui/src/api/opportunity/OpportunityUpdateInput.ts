import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { SkillsetUpdateManyWithoutOpportunitiesInput } from "./SkillsetUpdateManyWithoutOpportunitiesInput";

export type OpportunityUpdateInput = {
  assignedCommunity?: CommunityWhereUniqueInput | null;
  claimedPerson?: EmployeeWhereUniqueInput | null;
  experienceRequired?: number | null;
  firm?: string | null;
  mappedPerson?: EmployeeWhereUniqueInput | null;
  requiredCloseDate?: Date | null;
  skillsetNeeded?: SkillsetUpdateManyWithoutOpportunitiesInput;
  status?: string | null;
};
