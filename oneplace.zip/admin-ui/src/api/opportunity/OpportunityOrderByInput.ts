import { SortOrder } from "../../util/SortOrder";

export type OpportunityOrderByInput = {
  assignedCommunityId?: SortOrder;
  claimedPersonId?: SortOrder;
  createdAt?: SortOrder;
  experienceRequired?: SortOrder;
  firm?: SortOrder;
  id?: SortOrder;
  mappedPersonId?: SortOrder;
  requiredCloseDate?: SortOrder;
  status?: SortOrder;
  updatedAt?: SortOrder;
};
