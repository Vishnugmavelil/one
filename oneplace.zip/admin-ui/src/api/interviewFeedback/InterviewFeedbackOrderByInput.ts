import { SortOrder } from "../../util/SortOrder";

export type InterviewFeedbackOrderByInput = {
  createdAt?: SortOrder;
  date?: SortOrder;
  feedback?: SortOrder;
  id?: SortOrder;
  interviewerId?: SortOrder;
  updatedAt?: SortOrder;
};
