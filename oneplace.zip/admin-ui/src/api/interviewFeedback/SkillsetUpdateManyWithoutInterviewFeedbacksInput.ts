import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetUpdateManyWithoutInterviewFeedbacksInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
  disconnect?: Array<SkillsetWhereUniqueInput>;
  set?: Array<SkillsetWhereUniqueInput>;
};
