import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";

export type CandidateUpdateManyWithoutInterviewFeedbacksInput = {
  connect?: Array<CandidateWhereUniqueInput>;
  disconnect?: Array<CandidateWhereUniqueInput>;
  set?: Array<CandidateWhereUniqueInput>;
};
