import { CandidateUpdateManyWithoutInterviewFeedbacksInput } from "./CandidateUpdateManyWithoutInterviewFeedbacksInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { SkillsetUpdateManyWithoutInterviewFeedbacksInput } from "./SkillsetUpdateManyWithoutInterviewFeedbacksInput";

export type InterviewFeedbackUpdateInput = {
  candidates?: CandidateUpdateManyWithoutInterviewFeedbacksInput;
  date?: Date | null;
  feedback?: string | null;
  interviewer?: EmployeeWhereUniqueInput | null;
  skillsetRanking?: SkillsetUpdateManyWithoutInterviewFeedbacksInput;
};
