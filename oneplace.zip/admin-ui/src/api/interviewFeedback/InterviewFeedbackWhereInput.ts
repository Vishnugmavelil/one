import { CandidateListRelationFilter } from "../candidate/CandidateListRelationFilter";
import { DateTimeNullableFilter } from "../../util/DateTimeNullableFilter";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { SkillsetListRelationFilter } from "../skillset/SkillsetListRelationFilter";

export type InterviewFeedbackWhereInput = {
  candidates?: CandidateListRelationFilter;
  date?: DateTimeNullableFilter;
  feedback?: StringNullableFilter;
  id?: StringFilter;
  interviewer?: EmployeeWhereUniqueInput;
  skillsetRanking?: SkillsetListRelationFilter;
};
