import { CandidateCreateNestedManyWithoutInterviewFeedbacksInput } from "./CandidateCreateNestedManyWithoutInterviewFeedbacksInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { SkillsetCreateNestedManyWithoutInterviewFeedbacksInput } from "./SkillsetCreateNestedManyWithoutInterviewFeedbacksInput";

export type InterviewFeedbackCreateInput = {
  candidates?: CandidateCreateNestedManyWithoutInterviewFeedbacksInput;
  date?: Date | null;
  feedback?: string | null;
  interviewer?: EmployeeWhereUniqueInput | null;
  skillsetRanking?: SkillsetCreateNestedManyWithoutInterviewFeedbacksInput;
};
