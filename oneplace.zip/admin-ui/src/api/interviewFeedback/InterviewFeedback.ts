import { Candidate } from "../candidate/Candidate";
import { Employee } from "../employee/Employee";
import { Skillset } from "../skillset/Skillset";

export type InterviewFeedback = {
  candidates?: Array<Candidate>;
  createdAt: Date;
  date: Date | null;
  feedback: string | null;
  id: string;
  interviewer?: Employee | null;
  skillsetRanking?: Array<Skillset>;
  updatedAt: Date;
};
