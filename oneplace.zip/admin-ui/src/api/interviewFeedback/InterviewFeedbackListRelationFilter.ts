import { InterviewFeedbackWhereInput } from "./InterviewFeedbackWhereInput";

export type InterviewFeedbackListRelationFilter = {
  every?: InterviewFeedbackWhereInput;
  some?: InterviewFeedbackWhereInput;
  none?: InterviewFeedbackWhereInput;
};
