import { SkillsetWhereUniqueInput } from "../skillset/SkillsetWhereUniqueInput";

export type SkillsetCreateNestedManyWithoutInterviewFeedbacksInput = {
  connect?: Array<SkillsetWhereUniqueInput>;
};
