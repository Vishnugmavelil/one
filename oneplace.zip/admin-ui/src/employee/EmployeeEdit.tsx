import * as React from "react";

import {
  Edit,
  SimpleForm,
  EditProps,
  TextInput,
  DateInput,
  ReferenceInput,
  SelectInput,
  NumberInput,
  ReferenceArrayInput,
  SelectArrayInput,
} from "react-admin";

import { CommunityTitle } from "../community/CommunityTitle";
import { InterviewFeedbackTitle } from "../interviewFeedback/InterviewFeedbackTitle";
import { OpportunityTitle } from "../opportunity/OpportunityTitle";

export const EmployeeEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <TextInput label="aadhar_number" source="aadharNumber" />
        <TextInput label="address" multiline source="address" />
        <TextInput label="blood_group" source="bloodGroup" />
        <DateInput label="career_start_date" source="careerStartDate" />
        <ReferenceInput
          source="community.id"
          reference="Community"
          label="community"
        >
          <SelectInput optionText={CommunityTitle} />
        </ReferenceInput>
        <TextInput label="contact_number" source="contactNumber" />
        <DateInput label="course_out_date" source="courseOutDate" />
        <DateInput label="date_of_joining" source="dateOfJoining" />
        <TextInput label="designation" source="designation" />
        <DateInput label="dob" source="dob" />
        <TextInput label="email" source="email" type="email" />
        <NumberInput
          step={1}
          label="emergency_contact_number"
          source="emergencyContactNumber"
        />
        <NumberInput label="fw_experience" source="fwExperience" />
        <TextInput label="gender" source="gender" />
        <TextInput label="image" source="image" />
        <ReferenceArrayInput
          source="interviewFeedbacks"
          reference="InterviewFeedback"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={InterviewFeedbackTitle} />
        </ReferenceArrayInput>
        <ReferenceArrayInput
          source="mappedOpportunity"
          reference="Opportunity"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={OpportunityTitle} />
        </ReferenceArrayInput>
        <TextInput label="name" source="name" />
        <ReferenceArrayInput
          source="opportunities"
          reference="Opportunity"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={OpportunityTitle} />
        </ReferenceArrayInput>
        <TextInput label="pan_number" source="panNumber" />
        <TextInput
          label="personal_mail_id"
          source="personalMailId"
          type="email"
        />
        <NumberInput label="total_experience" source="totalExperience" />
      </SimpleForm>
    </Edit>
  );
};
