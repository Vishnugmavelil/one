import * as React from "react";

import {
  Show,
  SimpleShowLayout,
  ShowProps,
  TextField,
  ReferenceField,
  DateField,
  ReferenceManyField,
  Datagrid,
} from "react-admin";

import { EMPLOYEE_TITLE_FIELD } from "./EmployeeTitle";
import { COMMUNITY_TITLE_FIELD } from "../community/CommunityTitle";

export const EmployeeShow = (props: ShowProps): React.ReactElement => {
  return (
    <Show {...props}>
      <SimpleShowLayout>
        <TextField label="aadhar_number" source="aadharNumber" />
        <TextField label="address" source="address" />
        <TextField label="blood_group" source="bloodGroup" />
        <TextField label="career_start_date" source="careerStartDate" />
        <ReferenceField
          label="community"
          source="community.id"
          reference="Community"
        >
          <TextField source={COMMUNITY_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="contact_number" source="contactNumber" />
        <TextField label="course_out_date" source="courseOutDate" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="date_of_joining" source="dateOfJoining" />
        <TextField label="designation" source="designation" />
        <TextField label="dob" source="dob" />
        <TextField label="email" source="email" />
        <TextField
          label="emergency_contact_number"
          source="emergencyContactNumber"
        />
        <TextField label="fw_experience" source="fwExperience" />
        <TextField label="gender" source="gender" />
        <TextField label="ID" source="id" />
        <TextField label="image" source="image" />
        <TextField label="name" source="name" />
        <TextField label="pan_number" source="panNumber" />
        <TextField label="personal_mail_id" source="personalMailId" />
        <TextField label="total_experience" source="totalExperience" />
        <DateField source="updatedAt" label="Updated At" />
        <ReferenceManyField
          reference="InterviewFeedback"
          target="EmployeeId"
          label="interview_feedbacks"
        >
          <Datagrid rowClick="show">
            <DateField source="createdAt" label="Created At" />
            <TextField label="date" source="date" />
            <TextField label="feedback" source="feedback" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="interviewer"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
        <ReferenceManyField
          reference="Opportunity"
          target="EmployeeId"
          label="opportunities"
        >
          <Datagrid rowClick="show">
            <ReferenceField
              label="assigned_community"
              source="community.id"
              reference="Community"
            >
              <TextField source={COMMUNITY_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="claimed_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField
              label="experience_required"
              source="experienceRequired"
            />
            <TextField label="firm" source="firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="mapped_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="required_close_date" source="requiredCloseDate" />
            <TextField label="status" source="status" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
        <ReferenceManyField
          reference="Opportunity"
          target="EmployeeId"
          label="opportunities"
        >
          <Datagrid rowClick="show">
            <ReferenceField
              label="assigned_community"
              source="community.id"
              reference="Community"
            >
              <TextField source={COMMUNITY_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="claimed_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField
              label="experience_required"
              source="experienceRequired"
            />
            <TextField label="firm" source="firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="mapped_person"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="required_close_date" source="requiredCloseDate" />
            <TextField label="status" source="status" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
      </SimpleShowLayout>
    </Show>
  );
};
