import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  TextField,
  ReferenceField,
  DateField,
} from "react-admin";
import Pagination from "../Components/Pagination";
import { COMMUNITY_TITLE_FIELD } from "../community/CommunityTitle";

export const EmployeeList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"employees"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <TextField label="aadhar_number" source="aadharNumber" />
        <TextField label="address" source="address" />
        <TextField label="blood_group" source="bloodGroup" />
        <TextField label="career_start_date" source="careerStartDate" />
        <ReferenceField
          label="community"
          source="community.id"
          reference="Community"
        >
          <TextField source={COMMUNITY_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="contact_number" source="contactNumber" />
        <TextField label="course_out_date" source="courseOutDate" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="date_of_joining" source="dateOfJoining" />
        <TextField label="designation" source="designation" />
        <TextField label="dob" source="dob" />
        <TextField label="email" source="email" />
        <TextField
          label="emergency_contact_number"
          source="emergencyContactNumber"
        />
        <TextField label="fw_experience" source="fwExperience" />
        <TextField label="gender" source="gender" />
        <TextField label="ID" source="id" />
        <TextField label="image" source="image" />
        <TextField label="name" source="name" />
        <TextField label="pan_number" source="panNumber" />
        <TextField label="personal_mail_id" source="personalMailId" />
        <TextField label="total_experience" source="totalExperience" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
