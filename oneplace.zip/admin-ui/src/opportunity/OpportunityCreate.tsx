import * as React from "react";

import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
  NumberInput,
  TextInput,
  DateTimeInput,
  ReferenceArrayInput,
  SelectArrayInput,
} from "react-admin";

import { CommunityTitle } from "../community/CommunityTitle";
import { EmployeeTitle } from "../employee/EmployeeTitle";
import { SkillsetTitle } from "../skillset/SkillsetTitle";

export const OpportunityCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="community.id"
          reference="Community"
          label="assigned_community"
        >
          <SelectInput optionText={CommunityTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="claimed_person"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <NumberInput label="experience_required" source="experienceRequired" />
        <TextInput label="firm" source="firm" />
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="mapped_person"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <DateTimeInput label="required_close_date" source="requiredCloseDate" />
        <ReferenceArrayInput
          source="skillsetNeeded"
          reference="Skillset"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={SkillsetTitle} />
        </ReferenceArrayInput>
        <TextInput label="status" source="status" />
      </SimpleForm>
    </Create>
  );
};
