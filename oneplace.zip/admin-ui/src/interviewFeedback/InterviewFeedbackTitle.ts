import { InterviewFeedback as TInterviewFeedback } from "../api/interviewFeedback/InterviewFeedback";

export const INTERVIEWFEEDBACK_TITLE_FIELD = "id";

export const InterviewFeedbackTitle = (record: TInterviewFeedback): string => {
  return record.id || record.id;
};
