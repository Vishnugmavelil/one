import * as React from "react";
import {
  Show,
  SimpleShowLayout,
  ShowProps,
  TextField,
  DateField,
  BooleanField,
} from "react-admin";

export const CandidateShow = (props: ShowProps): React.ReactElement => {
  return (
    <Show {...props}>
      <SimpleShowLayout>
        <TextField label="additional_comments" source="additionalComments" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="current_firm" source="currentFirm" />
        <TextField label="current_status" source="currentStatus" />
        <TextField label="email" source="email" />
        <TextField label="ID" source="id" />
        <BooleanField label="is_on_notice_period" source="isOnNoticePeriod" />
        <TextField label="last_working_day" source="lastWorkingDay" />
        <TextField label="name" source="name" />
        <TextField label="notice_period_time" source="noticePeriodTime" />
        <DateField source="updatedAt" label="Updated At" />
      </SimpleShowLayout>
    </Show>
  );
};
