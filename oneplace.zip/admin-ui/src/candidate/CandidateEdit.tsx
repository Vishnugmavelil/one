import * as React from "react";

import {
  Edit,
  SimpleForm,
  EditProps,
  TextInput,
  ReferenceArrayInput,
  SelectArrayInput,
  BooleanInput,
  DateInput,
  NumberInput,
} from "react-admin";

import { InterviewFeedbackTitle } from "../interviewFeedback/InterviewFeedbackTitle";
import { SkillsetTitle } from "../skillset/SkillsetTitle";

export const CandidateEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <TextInput
          label="additional_comments"
          multiline
          source="additionalComments"
        />
        <TextInput label="current_firm" source="currentFirm" />
        <TextInput label="current_status" source="currentStatus" />
        <TextInput label="email" source="email" type="email" />
        <ReferenceArrayInput
          source="interviewFeedback"
          reference="InterviewFeedback"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={InterviewFeedbackTitle} />
        </ReferenceArrayInput>
        <BooleanInput label="is_on_notice_period" source="isOnNoticePeriod" />
        <DateInput label="last_working_day" source="lastWorkingDay" />
        <TextInput label="name" source="name" />
        <NumberInput
          step={1}
          label="notice_period_time"
          source="noticePeriodTime"
        />
        <ReferenceArrayInput
          source="skillset"
          reference="Skillset"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={SkillsetTitle} />
        </ReferenceArrayInput>
      </SimpleForm>
    </Edit>
  );
};
