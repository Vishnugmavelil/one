import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  TextField,
  DateField,
  BooleanField,
} from "react-admin";
import Pagination from "../Components/Pagination";

export const CandidateList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"candidates"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <TextField label="additional_comments" source="additionalComments" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="current_firm" source="currentFirm" />
        <TextField label="current_status" source="currentStatus" />
        <TextField label="email" source="email" />
        <TextField label="ID" source="id" />
        <BooleanField label="is_on_notice_period" source="isOnNoticePeriod" />
        <TextField label="last_working_day" source="lastWorkingDay" />
        <TextField label="name" source="name" />
        <TextField label="notice_period_time" source="noticePeriodTime" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
