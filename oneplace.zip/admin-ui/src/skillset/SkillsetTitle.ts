import { Skillset as TSkillset } from "../api/skillset/Skillset";

export const SKILLSET_TITLE_FIELD = "skillName";

export const SkillsetTitle = (record: TSkillset): string => {
  return record.skillName || record.id;
};
