import { CandidateFeedback as TCandidateFeedback } from "../api/candidateFeedback/CandidateFeedback";

export const CANDIDATEFEEDBACK_TITLE_FIELD = "id";

export const CandidateFeedbackTitle = (record: TCandidateFeedback): string => {
  return record.id || record.id;
};
