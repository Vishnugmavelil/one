import * as React from "react";

import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
  DateInput,
  TextInput,
} from "react-admin";

import { CandidateFeedbackTitle } from "../candidateFeedback/CandidateFeedbackTitle";
import { FeedbackSkillTitle } from "../feedbackSkill/FeedbackSkillTitle";
import { EmployeeTitle } from "../employee/EmployeeTitle";

export const InterviewFeedbackCreate = (
  props: CreateProps
): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="candidatefeedback.id"
          reference="CandidateFeedback"
          label="candidate_feedbacks"
        >
          <SelectInput optionText={CandidateFeedbackTitle} />
        </ReferenceInput>
        <DateInput label="date" source="date" />
        <TextInput label="feedback" source="feedback" />
        <ReferenceInput
          source="feedbackskill.id"
          reference="FeedbackSkill"
          label="feedback_skills"
        >
          <SelectInput optionText={FeedbackSkillTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="interviewer"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Create>
  );
};
