import * as React from "react";
import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
  TextInput,
} from "react-admin";
import { CandidateTitle } from "../candidate/CandidateTitle";
import { EmployeeResumeTitle } from "../employeeResume/EmployeeResumeTitle";

export const ResumeCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="candidate.id"
          reference="Candidate"
          label="candidates"
        >
          <SelectInput optionText={CandidateTitle} />
        </ReferenceInput>
        <TextInput label="comment" source="comment" />
        <TextInput label="document" source="document" />
        <ReferenceInput
          source="employeeresume.id"
          reference="EmployeeResume"
          label="employee_resumes"
        >
          <SelectInput optionText={EmployeeResumeTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Create>
  );
};
