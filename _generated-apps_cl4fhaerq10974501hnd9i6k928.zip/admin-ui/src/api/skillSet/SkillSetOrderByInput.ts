import { SortOrder } from "../../util/SortOrder";

export type SkillSetOrderByInput = {
  candidateSkillsId?: SortOrder;
  comments?: SortOrder;
  createdAt?: SortOrder;
  expertise_level?: SortOrder;
  feedbackSkillsId?: SortOrder;
  id?: SortOrder;
  opportunitiesSkillsId?: SortOrder;
  skill_name?: SortOrder;
  updatedAt?: SortOrder;
};
