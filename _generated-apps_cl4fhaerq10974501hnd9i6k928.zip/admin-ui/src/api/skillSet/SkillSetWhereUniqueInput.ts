export type SkillSetWhereUniqueInput = {
  id: string;
};
