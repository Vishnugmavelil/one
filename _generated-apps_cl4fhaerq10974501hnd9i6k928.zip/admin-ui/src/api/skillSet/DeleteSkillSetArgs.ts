import { SkillSetWhereUniqueInput } from "./SkillSetWhereUniqueInput";

export type DeleteSkillSetArgs = {
  where: SkillSetWhereUniqueInput;
};
