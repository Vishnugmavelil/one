import { CandidateSkillWhereUniqueInput } from "../candidateSkill/CandidateSkillWhereUniqueInput";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { FeedbackSkillWhereUniqueInput } from "../feedbackSkill/FeedbackSkillWhereUniqueInput";
import { OpportunitiesSkillWhereUniqueInput } from "../opportunitiesSkill/OpportunitiesSkillWhereUniqueInput";

export type SkillSetWhereInput = {
  candidateSkills?: CandidateSkillWhereUniqueInput;
  comments?: StringNullableFilter;
  expertise_level?: StringFilter;
  feedbackSkills?: FeedbackSkillWhereUniqueInput;
  id?: StringFilter;
  opportunitiesSkills?: OpportunitiesSkillWhereUniqueInput;
  skill_name?: StringFilter;
};
