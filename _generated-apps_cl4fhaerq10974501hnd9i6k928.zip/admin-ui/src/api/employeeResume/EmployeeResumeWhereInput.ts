import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { ResumeWhereUniqueInput } from "../resume/ResumeWhereUniqueInput";

export type EmployeeResumeWhereInput = {
  employeeId?: EmployeeWhereUniqueInput;
  id?: StringFilter;
  resumeId?: ResumeWhereUniqueInput;
};
