import { EmployeeResumeWhereInput } from "./EmployeeResumeWhereInput";
import { EmployeeResumeOrderByInput } from "./EmployeeResumeOrderByInput";

export type EmployeeResumeFindManyArgs = {
  where?: EmployeeResumeWhereInput;
  orderBy?: Array<EmployeeResumeOrderByInput>;
  skip?: number;
  take?: number;
};
