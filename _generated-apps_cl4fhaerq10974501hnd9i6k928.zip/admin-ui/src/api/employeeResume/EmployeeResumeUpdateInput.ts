import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { ResumeWhereUniqueInput } from "../resume/ResumeWhereUniqueInput";

export type EmployeeResumeUpdateInput = {
  employeeId?: EmployeeWhereUniqueInput;
  resumeId?: ResumeWhereUniqueInput;
};
