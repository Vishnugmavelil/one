import { EmployeeResumeWhereUniqueInput } from "./EmployeeResumeWhereUniqueInput";

export type EmployeeResumeFindUniqueArgs = {
  where: EmployeeResumeWhereUniqueInput;
};
