import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type OpportunitiesSkillUpdateInput = {
  opportunities_id?: OpportunityWhereUniqueInput;
  skillId?: SkillSetWhereUniqueInput;
};
