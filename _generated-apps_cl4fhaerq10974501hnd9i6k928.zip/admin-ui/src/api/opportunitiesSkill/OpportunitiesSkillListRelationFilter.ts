import { OpportunitiesSkillWhereInput } from "./OpportunitiesSkillWhereInput";

export type OpportunitiesSkillListRelationFilter = {
  every?: OpportunitiesSkillWhereInput;
  some?: OpportunitiesSkillWhereInput;
  none?: OpportunitiesSkillWhereInput;
};
