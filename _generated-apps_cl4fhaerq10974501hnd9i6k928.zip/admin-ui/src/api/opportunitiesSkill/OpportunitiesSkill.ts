import { Opportunity } from "../opportunity/Opportunity";
import { SkillSet } from "../skillSet/SkillSet";

export type OpportunitiesSkill = {
  createdAt: Date;
  id: string;
  opportunities_id?: Opportunity;
  skillId?: SkillSet;
  updatedAt: Date;
};
