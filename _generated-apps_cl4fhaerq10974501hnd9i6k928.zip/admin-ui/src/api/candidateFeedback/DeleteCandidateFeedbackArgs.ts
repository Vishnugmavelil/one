import { CandidateFeedbackWhereUniqueInput } from "./CandidateFeedbackWhereUniqueInput";

export type DeleteCandidateFeedbackArgs = {
  where: CandidateFeedbackWhereUniqueInput;
};
