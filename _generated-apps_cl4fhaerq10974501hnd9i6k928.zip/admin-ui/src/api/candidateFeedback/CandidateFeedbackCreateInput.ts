import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";

export type CandidateFeedbackCreateInput = {
  candidate_id: CandidateWhereUniqueInput;
  feedback_id: InterviewFeedbackWhereUniqueInput;
};
