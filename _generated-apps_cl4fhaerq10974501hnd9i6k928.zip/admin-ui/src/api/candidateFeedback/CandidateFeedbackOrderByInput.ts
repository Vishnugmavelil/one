import { SortOrder } from "../../util/SortOrder";

export type CandidateFeedbackOrderByInput = {
  candidate_idId?: SortOrder;
  createdAt?: SortOrder;
  feedback_idId?: SortOrder;
  id?: SortOrder;
  updatedAt?: SortOrder;
};
