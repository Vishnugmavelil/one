import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";

export type InterviewUpdateInput = {
  assigned_hr?: EmployeeWhereUniqueInput;
  assigned_recruiter?: EmployeeWhereUniqueInput;
  candidate?: CandidateWhereUniqueInput;
  date?: Date;
  interviewer?: EmployeeWhereUniqueInput;
  interview_feedback?: CandidateWhereUniqueInput;
  level?: string;
};
