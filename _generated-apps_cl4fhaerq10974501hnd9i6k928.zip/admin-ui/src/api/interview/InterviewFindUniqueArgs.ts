import { InterviewWhereUniqueInput } from "./InterviewWhereUniqueInput";

export type InterviewFindUniqueArgs = {
  where: InterviewWhereUniqueInput;
};
