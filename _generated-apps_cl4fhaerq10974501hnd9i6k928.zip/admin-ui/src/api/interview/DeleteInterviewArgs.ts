import { InterviewWhereUniqueInput } from "./InterviewWhereUniqueInput";

export type DeleteInterviewArgs = {
  where: InterviewWhereUniqueInput;
};
