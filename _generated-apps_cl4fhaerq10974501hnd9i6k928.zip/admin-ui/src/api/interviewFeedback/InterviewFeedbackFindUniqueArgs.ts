import { InterviewFeedbackWhereUniqueInput } from "./InterviewFeedbackWhereUniqueInput";

export type InterviewFeedbackFindUniqueArgs = {
  where: InterviewFeedbackWhereUniqueInput;
};
