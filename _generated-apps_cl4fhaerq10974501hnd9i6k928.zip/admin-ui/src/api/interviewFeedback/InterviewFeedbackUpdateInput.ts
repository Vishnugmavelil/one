import { CandidateFeedbackWhereUniqueInput } from "../candidateFeedback/CandidateFeedbackWhereUniqueInput";
import { FeedbackSkillWhereUniqueInput } from "../feedbackSkill/FeedbackSkillWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";

export type InterviewFeedbackUpdateInput = {
  candidateFeedbacks?: CandidateFeedbackWhereUniqueInput;
  date?: Date;
  feedback?: string | null;
  feedbackSkills?: FeedbackSkillWhereUniqueInput;
  interviewer?: EmployeeWhereUniqueInput;
};
