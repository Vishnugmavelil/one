import { CandidateFeedback } from "../candidateFeedback/CandidateFeedback";
import { CandidateSkill } from "../candidateSkill/CandidateSkill";
import { Interview } from "../interview/Interview";
import { Resume } from "../resume/Resume";

export type Candidate = {
  additional_comments: string | null;
  candidateFeedbacks?: CandidateFeedback;
  candidatesEmail?: Array<Candidate>;
  candidateskill?: CandidateSkill;
  candidatesNoticePeriod?: Candidate | null;
  createdAt: Date;
  current_firm: string | null;
  current_status?: Array<Candidate>;
  id: string;
  interviewFeedback?: Array<Interview>;
  interviews?: Interview;
  is_on_notice_period: boolean;
  last_workingday: Date;
  name?: Candidate;
  resume?: Resume | null;
  skill_Set: string | null;
  updatedAt: Date;
};
