import { CandidateFeedbackWhereUniqueInput } from "../candidateFeedback/CandidateFeedbackWhereUniqueInput";
import { CandidateCreateNestedManyWithoutCandidatesInput } from "./CandidateCreateNestedManyWithoutCandidatesInput";
import { CandidateSkillWhereUniqueInput } from "../candidateSkill/CandidateSkillWhereUniqueInput";
import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";
import { InterviewCreateNestedManyWithoutCandidatesInput } from "./InterviewCreateNestedManyWithoutCandidatesInput";
import { InterviewWhereUniqueInput } from "../interview/InterviewWhereUniqueInput";
import { ResumeWhereUniqueInput } from "../resume/ResumeWhereUniqueInput";

export type CandidateCreateInput = {
  additional_comments?: string | null;
  candidateFeedbacks?: CandidateFeedbackWhereUniqueInput;
  candidatesEmail?: CandidateCreateNestedManyWithoutCandidatesInput;
  candidateskill: CandidateSkillWhereUniqueInput;
  candidatesNoticePeriod?: CandidateWhereUniqueInput | null;
  current_firm?: string | null;
  current_status?: CandidateCreateNestedManyWithoutCandidatesInput;
  interviewFeedback?: InterviewCreateNestedManyWithoutCandidatesInput;
  interviews?: InterviewWhereUniqueInput;
  is_on_notice_period: boolean;
  last_workingday: Date;
  name: CandidateWhereUniqueInput;
  resume?: ResumeWhereUniqueInput | null;
  skill_Set?: string | null;
};
