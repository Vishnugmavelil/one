import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";

export type CandidateFindUniqueArgs = {
  where: CandidateWhereUniqueInput;
};
