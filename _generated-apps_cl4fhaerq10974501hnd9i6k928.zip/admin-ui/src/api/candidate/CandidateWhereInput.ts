import { StringNullableFilter } from "../../util/StringNullableFilter";
import { CandidateFeedbackWhereUniqueInput } from "../candidateFeedback/CandidateFeedbackWhereUniqueInput";
import { CandidateListRelationFilter } from "./CandidateListRelationFilter";
import { CandidateSkillWhereUniqueInput } from "../candidateSkill/CandidateSkillWhereUniqueInput";
import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { InterviewListRelationFilter } from "../interview/InterviewListRelationFilter";
import { InterviewWhereUniqueInput } from "../interview/InterviewWhereUniqueInput";
import { BooleanFilter } from "../../util/BooleanFilter";
import { DateTimeFilter } from "../../util/DateTimeFilter";
import { ResumeWhereUniqueInput } from "../resume/ResumeWhereUniqueInput";

export type CandidateWhereInput = {
  additional_comments?: StringNullableFilter;
  candidateFeedbacks?: CandidateFeedbackWhereUniqueInput;
  candidatesEmail?: CandidateListRelationFilter;
  candidateskill?: CandidateSkillWhereUniqueInput;
  candidatesNoticePeriod?: CandidateWhereUniqueInput;
  current_firm?: StringNullableFilter;
  current_status?: CandidateListRelationFilter;
  id?: StringFilter;
  interviewFeedback?: InterviewListRelationFilter;
  interviews?: InterviewWhereUniqueInput;
  is_on_notice_period?: BooleanFilter;
  last_workingday?: DateTimeFilter;
  name?: CandidateWhereUniqueInput;
  resume?: ResumeWhereUniqueInput;
  skill_Set?: StringNullableFilter;
};
