import { SortOrder } from "../../util/SortOrder";

export type CandidateOrderByInput = {
  additional_comments?: SortOrder;
  candidateFeedbacksId?: SortOrder;
  candidateskillId?: SortOrder;
  candidatesNoticePeriodId?: SortOrder;
  createdAt?: SortOrder;
  current_firm?: SortOrder;
  id?: SortOrder;
  interviewsId?: SortOrder;
  is_on_notice_period?: SortOrder;
  last_workingday?: SortOrder;
  nameId?: SortOrder;
  resumeId?: SortOrder;
  skill_Set?: SortOrder;
  updatedAt?: SortOrder;
};
