import { OpportunityWhereUniqueInput } from "./OpportunityWhereUniqueInput";

export type DeleteOpportunityArgs = {
  where: OpportunityWhereUniqueInput;
};
