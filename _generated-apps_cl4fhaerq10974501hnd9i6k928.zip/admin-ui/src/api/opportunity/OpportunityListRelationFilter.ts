import { OpportunityWhereInput } from "./OpportunityWhereInput";

export type OpportunityListRelationFilter = {
  every?: OpportunityWhereInput;
  some?: OpportunityWhereInput;
  none?: OpportunityWhereInput;
};
