import { CommunityWhereUniqueInput } from "../community/CommunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { OpportunitiesSkillWhereUniqueInput } from "../opportunitiesSkill/OpportunitiesSkillWhereUniqueInput";

export type OpportunityUpdateInput = {
  AssignedCommunity?: CommunityWhereUniqueInput;
  ClaimedPerson?: EmployeeWhereUniqueInput | null;
  Experience_required?: number;
  firm?: string;
  mappedPerson?: EmployeeWhereUniqueInput | null;
  opportunitiesSkills?: OpportunitiesSkillWhereUniqueInput;
  Required_close_date?: Date;
  Status?: string | null;
};
