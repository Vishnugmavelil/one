import { SortOrder } from "../../util/SortOrder";

export type OpportunityOrderByInput = {
  AssignedCommunityId?: SortOrder;
  ClaimedPersonId?: SortOrder;
  createdAt?: SortOrder;
  Experience_required?: SortOrder;
  firm?: SortOrder;
  id?: SortOrder;
  mappedPersonId?: SortOrder;
  opportunitiesSkillsId?: SortOrder;
  Required_close_date?: SortOrder;
  Status?: SortOrder;
  updatedAt?: SortOrder;
};
