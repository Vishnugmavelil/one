import { SortOrder } from "../../util/SortOrder";

export type CommunityOrderByInput = {
  communityIdId?: SortOrder;
  createdAt?: SortOrder;
  description?: SortOrder;
  employeesId?: SortOrder;
  id?: SortOrder;
  name?: SortOrder;
  updatedAt?: SortOrder;
};
