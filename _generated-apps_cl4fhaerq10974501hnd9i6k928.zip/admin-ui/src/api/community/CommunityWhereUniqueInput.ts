export type CommunityWhereUniqueInput = {
  id: string;
};
