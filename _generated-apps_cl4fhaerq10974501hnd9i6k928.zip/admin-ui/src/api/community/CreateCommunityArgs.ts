import { CommunityCreateInput } from "./CommunityCreateInput";

export type CreateCommunityArgs = {
  data: CommunityCreateInput;
};
