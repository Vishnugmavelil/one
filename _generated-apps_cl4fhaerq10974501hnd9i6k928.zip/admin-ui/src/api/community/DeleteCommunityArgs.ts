import { CommunityWhereUniqueInput } from "./CommunityWhereUniqueInput";

export type DeleteCommunityArgs = {
  where: CommunityWhereUniqueInput;
};
