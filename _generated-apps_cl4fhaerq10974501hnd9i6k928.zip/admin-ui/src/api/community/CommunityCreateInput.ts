import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";

export type CommunityCreateInput = {
  communityId: OpportunityWhereUniqueInput;
  description?: string | null;
  employees: EmployeeWhereUniqueInput;
  name: string;
};
