import { Candidate } from "../candidate/Candidate";
import { SkillSet } from "../skillSet/SkillSet";

export type CandidateSkill = {
  candidateId?: Candidate;
  createdAt: Date;
  id: string;
  skill_id?: SkillSet;
  updatedAt: Date;
};
