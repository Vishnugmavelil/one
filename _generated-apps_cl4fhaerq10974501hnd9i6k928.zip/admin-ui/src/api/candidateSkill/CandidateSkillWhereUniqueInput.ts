export type CandidateSkillWhereUniqueInput = {
  id: string;
};
