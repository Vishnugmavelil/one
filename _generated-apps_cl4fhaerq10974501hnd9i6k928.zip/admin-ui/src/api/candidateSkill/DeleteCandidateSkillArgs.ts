import { CandidateSkillWhereUniqueInput } from "./CandidateSkillWhereUniqueInput";

export type DeleteCandidateSkillArgs = {
  where: CandidateSkillWhereUniqueInput;
};
