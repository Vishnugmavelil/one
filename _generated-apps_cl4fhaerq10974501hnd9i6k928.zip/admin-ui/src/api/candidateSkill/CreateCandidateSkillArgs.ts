import { CandidateSkillCreateInput } from "./CandidateSkillCreateInput";

export type CreateCandidateSkillArgs = {
  data: CandidateSkillCreateInput;
};
