import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type FeedbackSkillWhereInput = {
  feedbackId?: InterviewFeedbackWhereUniqueInput;
  id?: StringFilter;
  skillId?: SkillSetWhereUniqueInput;
};
