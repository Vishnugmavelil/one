export type FeedbackSkillWhereUniqueInput = {
  id: string;
};
