import { FeedbackSkillWhereUniqueInput } from "./FeedbackSkillWhereUniqueInput";

export type DeleteFeedbackSkillArgs = {
  where: FeedbackSkillWhereUniqueInput;
};
