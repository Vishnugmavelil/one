import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type FeedbackSkillCreateInput = {
  feedbackId: InterviewFeedbackWhereUniqueInput;
  skillId: SkillSetWhereUniqueInput;
};
