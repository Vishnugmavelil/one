import { ResumeWhereInput } from "./ResumeWhereInput";

export type ResumeListRelationFilter = {
  every?: ResumeWhereInput;
  some?: ResumeWhereInput;
  none?: ResumeWhereInput;
};
