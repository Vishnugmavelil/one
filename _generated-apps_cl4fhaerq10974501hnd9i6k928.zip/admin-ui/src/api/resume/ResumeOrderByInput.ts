import { SortOrder } from "../../util/SortOrder";

export type ResumeOrderByInput = {
  candidatesId?: SortOrder;
  comment?: SortOrder;
  createdAt?: SortOrder;
  document?: SortOrder;
  employeeResumesId?: SortOrder;
  id?: SortOrder;
  updatedAt?: SortOrder;
};
