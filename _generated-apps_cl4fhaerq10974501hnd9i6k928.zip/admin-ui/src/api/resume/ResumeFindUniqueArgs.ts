import { ResumeWhereUniqueInput } from "./ResumeWhereUniqueInput";

export type ResumeFindUniqueArgs = {
  where: ResumeWhereUniqueInput;
};
