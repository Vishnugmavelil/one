import { ResumeCreateInput } from "./ResumeCreateInput";

export type CreateResumeArgs = {
  data: ResumeCreateInput;
};
