import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type OpportunityUpdateManyWithoutEmployeesInput = {
  connect?: Array<OpportunityWhereUniqueInput>;
  disconnect?: Array<OpportunityWhereUniqueInput>;
  set?: Array<OpportunityWhereUniqueInput>;
};
