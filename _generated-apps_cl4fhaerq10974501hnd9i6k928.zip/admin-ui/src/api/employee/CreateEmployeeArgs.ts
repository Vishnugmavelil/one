import { EmployeeCreateInput } from "./EmployeeCreateInput";

export type CreateEmployeeArgs = {
  data: EmployeeCreateInput;
};
