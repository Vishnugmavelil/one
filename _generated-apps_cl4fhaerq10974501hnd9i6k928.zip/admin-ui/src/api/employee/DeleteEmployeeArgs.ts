import { EmployeeWhereUniqueInput } from "./EmployeeWhereUniqueInput";

export type DeleteEmployeeArgs = {
  where: EmployeeWhereUniqueInput;
};
