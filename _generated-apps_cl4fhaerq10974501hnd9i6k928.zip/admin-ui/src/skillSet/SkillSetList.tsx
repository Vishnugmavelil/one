import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  ReferenceField,
  TextField,
  DateField,
} from "react-admin";
import Pagination from "../Components/Pagination";
import { CANDIDATESKILL_TITLE_FIELD } from "../candidateSkill/CandidateSkillTitle";
import { FEEDBACKSKILL_TITLE_FIELD } from "../feedbackSkill/FeedbackSkillTitle";
import { OPPORTUNITIESSKILL_TITLE_FIELD } from "../opportunitiesSkill/OpportunitiesSkillTitle";

export const SkillSetList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"skill_sets"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <ReferenceField
          label="candidate_skills"
          source="candidateskill.id"
          reference="CandidateSkill"
        >
          <TextField source={CANDIDATESKILL_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="comments" source="comments" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="expertise_level" source="expertise_level" />
        <ReferenceField
          label="feedback_skills"
          source="feedbackskill.id"
          reference="FeedbackSkill"
        >
          <TextField source={FEEDBACKSKILL_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="ID" source="id" />
        <ReferenceField
          label="opportunities_skills"
          source="opportunitiesskill.id"
          reference="OpportunitiesSkill"
        >
          <TextField source={OPPORTUNITIESSKILL_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="skill_name" source="skill_name" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
