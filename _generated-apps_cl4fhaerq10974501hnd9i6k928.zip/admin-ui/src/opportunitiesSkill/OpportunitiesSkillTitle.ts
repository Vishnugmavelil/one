import { OpportunitiesSkill as TOpportunitiesSkill } from "../api/opportunitiesSkill/OpportunitiesSkill";

export const OPPORTUNITIESSKILL_TITLE_FIELD = "id";

export const OpportunitiesSkillTitle = (
  record: TOpportunitiesSkill
): string => {
  return record.id || record.id;
};
