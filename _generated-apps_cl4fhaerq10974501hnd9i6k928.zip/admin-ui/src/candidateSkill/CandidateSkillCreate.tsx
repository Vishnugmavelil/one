import * as React from "react";
import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { CandidateTitle } from "../candidate/CandidateTitle";
import { SkillSetTitle } from "../skillSet/SkillSetTitle";

export const CandidateSkillCreate = (
  props: CreateProps
): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="candidate.id"
          reference="Candidate"
          label="candidate_id"
        >
          <SelectInput optionText={CandidateTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="skillset.id"
          reference="SkillSet"
          label="skill_id"
        >
          <SelectInput optionText={SkillSetTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Create>
  );
};
