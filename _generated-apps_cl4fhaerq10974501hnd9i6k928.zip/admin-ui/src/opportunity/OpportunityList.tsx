import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  ReferenceField,
  TextField,
  DateField,
} from "react-admin";
import Pagination from "../Components/Pagination";
import { COMMUNITY_TITLE_FIELD } from "../community/CommunityTitle";
import { EMPLOYEE_TITLE_FIELD } from "../employee/EmployeeTitle";
import { OPPORTUNITIESSKILL_TITLE_FIELD } from "../opportunitiesSkill/OpportunitiesSkillTitle";

export const OpportunityList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"opportunities"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <ReferenceField
          label="AssignedCommunity"
          source="community.id"
          reference="Community"
        >
          <TextField source={COMMUNITY_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="ClaimedPerson"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <DateField source="createdAt" label="Created At" />
        <TextField label="Experience_required" source="Experience_required" />
        <TextField label="Firm" source="firm" />
        <TextField label="ID" source="id" />
        <ReferenceField
          label="MappedPerson"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="opportunities_skills"
          source="opportunitiesskill.id"
          reference="OpportunitiesSkill"
        >
          <TextField source={OPPORTUNITIESSKILL_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Required_close_date" source="Required_close_date" />
        <TextField label="Status" source="Status" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
