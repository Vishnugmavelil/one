import * as React from "react";

import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
  NumberInput,
  TextInput,
  DateTimeInput,
} from "react-admin";

import { CommunityTitle } from "../community/CommunityTitle";
import { EmployeeTitle } from "../employee/EmployeeTitle";
import { OpportunitiesSkillTitle } from "../opportunitiesSkill/OpportunitiesSkillTitle";

export const OpportunityCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="community.id"
          reference="Community"
          label="AssignedCommunity"
        >
          <SelectInput optionText={CommunityTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="ClaimedPerson"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <NumberInput
          step={1}
          label="Experience_required"
          source="Experience_required"
        />
        <TextInput label="Firm" source="firm" />
        <ReferenceInput
          source="employee.id"
          reference="Employee"
          label="MappedPerson"
        >
          <SelectInput optionText={EmployeeTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="opportunitiesskill.id"
          reference="OpportunitiesSkill"
          label="opportunities_skills"
        >
          <SelectInput optionText={OpportunitiesSkillTitle} />
        </ReferenceInput>
        <DateTimeInput
          label="Required_close_date"
          source="Required_close_date"
        />
        <TextInput label="Status" source="Status" />
      </SimpleForm>
    </Create>
  );
};
