import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as nestAccessControl from "nest-access-control";
import { GqlDefaultAuthGuard } from "../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../auth/gqlAC.guard";
import { CandidateFeedbackResolverBase } from "./base/candidateFeedback.resolver.base";
import { CandidateFeedback } from "./base/CandidateFeedback";
import { CandidateFeedbackService } from "./candidateFeedback.service";

@graphql.Resolver(() => CandidateFeedback)
@common.UseGuards(GqlDefaultAuthGuard, gqlACGuard.GqlACGuard)
export class CandidateFeedbackResolver extends CandidateFeedbackResolverBase {
  constructor(
    protected readonly service: CandidateFeedbackService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
