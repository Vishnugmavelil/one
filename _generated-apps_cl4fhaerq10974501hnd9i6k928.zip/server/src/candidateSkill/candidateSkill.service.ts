import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { CandidateSkillServiceBase } from "./base/candidateSkill.service.base";

@Injectable()
export class CandidateSkillService extends CandidateSkillServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
