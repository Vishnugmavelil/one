import * as React from "react";
import {
  List,
  Datagrid,
  ListProps,
  TextField,
  ReferenceField,
  DateField,
} from "react-admin";
import Pagination from "../Components/Pagination";
import { EMPLOYEE_TITLE_FIELD } from "./EmployeeTitle";
import { COMMUNITY_TITLE_FIELD } from "../community/CommunityTitle";
import { EMPLOYEERESUME_TITLE_FIELD } from "../employeeResume/EmployeeResumeTitle";
import { INTERVIEW_TITLE_FIELD } from "../interview/InterviewTitle";
import { INTERVIEWFEEDBACK_TITLE_FIELD } from "../interviewFeedback/InterviewFeedbackTitle";
import { OPPORTUNITY_TITLE_FIELD } from "../opportunity/OpportunityTitle";

export const EmployeeList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"employees"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <TextField label="Aadhar" source="Aadhar" />
        <ReferenceField
          label="address"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Blood_Group" source="Blood_Group" />
        <TextField label="career_start_date" source="career_start_date" />
        <ReferenceField
          label="Community"
          source="community.id"
          reference="Community"
        >
          <TextField source={COMMUNITY_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Contact_Number" source="contactNumber" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="date_of_joining" source="date_of_joining" />
        <TextField label="dob" source="dob" />
        <TextField label="email" source="email" />
        <TextField
          label="Emergency_Contact_Number"
          source="Emergency_Contact_Number"
        />
        <ReferenceField
          label="employee_resumes"
          source="employeeresume.id"
          reference="EmployeeResume"
        >
          <TextField source={EMPLOYEERESUME_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="employees_designation"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="employees_image"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="fw_experience" source="fw_experience" />
        <TextField label="gender" source="gender" />
        <ReferenceField
          label="hr_employee_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="ID" source="id" />
        <ReferenceField
          label="interview_feedbacks"
          source="interviewfeedback.id"
          reference="InterviewFeedback"
        >
          <TextField source={INTERVIEWFEEDBACK_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="interviews_empoyee_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="name" source="name" />
        <ReferenceField
          label="opportunities"
          source="opportunity.id"
          reference="Opportunity"
        >
          <TextField source={OPPORTUNITY_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="PAN_Number"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Personal_Mail_ID" source="Personal_Mail_ID" />
        <ReferenceField
          label="recruiter_employer_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="total_experience" source="total_experience" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
