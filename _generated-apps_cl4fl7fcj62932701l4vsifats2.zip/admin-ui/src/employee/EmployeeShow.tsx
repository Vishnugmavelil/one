import * as React from "react";

import {
  Show,
  SimpleShowLayout,
  ShowProps,
  TextField,
  ReferenceField,
  DateField,
  ReferenceManyField,
  Datagrid,
} from "react-admin";

import { COMMUNITY_TITLE_FIELD } from "../community/CommunityTitle";
import { EMPLOYEE_TITLE_FIELD } from "./EmployeeTitle";
import { OPPORTUNITIESSKILL_TITLE_FIELD } from "../opportunitiesSkill/OpportunitiesSkillTitle";
import { EMPLOYEERESUME_TITLE_FIELD } from "../employeeResume/EmployeeResumeTitle";
import { INTERVIEW_TITLE_FIELD } from "../interview/InterviewTitle";
import { INTERVIEWFEEDBACK_TITLE_FIELD } from "../interviewFeedback/InterviewFeedbackTitle";
import { OPPORTUNITY_TITLE_FIELD } from "../opportunity/OpportunityTitle";

export const EmployeeShow = (props: ShowProps): React.ReactElement => {
  return (
    <Show {...props}>
      <SimpleShowLayout>
        <TextField label="Aadhar" source="Aadhar" />
        <ReferenceField
          label="address"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Blood_Group" source="Blood_Group" />
        <TextField label="career_start_date" source="career_start_date" />
        <ReferenceField
          label="Community"
          source="community.id"
          reference="Community"
        >
          <TextField source={COMMUNITY_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Contact_Number" source="contactNumber" />
        <DateField source="createdAt" label="Created At" />
        <TextField label="date_of_joining" source="date_of_joining" />
        <TextField label="dob" source="dob" />
        <TextField label="email" source="email" />
        <TextField
          label="Emergency_Contact_Number"
          source="Emergency_Contact_Number"
        />
        <ReferenceField
          label="employee_resumes"
          source="employeeresume.id"
          reference="EmployeeResume"
        >
          <TextField source={EMPLOYEERESUME_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="employees_designation"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="employees_image"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="fw_experience" source="fw_experience" />
        <TextField label="gender" source="gender" />
        <ReferenceField
          label="hr_employee_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="ID" source="id" />
        <ReferenceField
          label="interview_feedbacks"
          source="interviewfeedback.id"
          reference="InterviewFeedback"
        >
          <TextField source={INTERVIEWFEEDBACK_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="interviews_empoyee_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="name" source="name" />
        <ReferenceField
          label="opportunities"
          source="opportunity.id"
          reference="Opportunity"
        >
          <TextField source={OPPORTUNITY_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="PAN_Number"
          source="employee.id"
          reference="Employee"
        >
          <TextField source={EMPLOYEE_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="Personal_Mail_ID" source="Personal_Mail_ID" />
        <ReferenceField
          label="recruiter_employer_id"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="total_experience" source="total_experience" />
        <DateField source="updatedAt" label="Updated At" />
        <ReferenceManyField
          reference="Opportunity"
          target="EmployeeId"
          label="opportunities"
        >
          <Datagrid rowClick="show">
            <ReferenceField
              label="AssignedCommunity"
              source="community.id"
              reference="Community"
            >
              <TextField source={COMMUNITY_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="ClaimedPerson"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField
              label="Experience_required"
              source="Experience_required"
            />
            <TextField label="Firm" source="firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="MappedPerson"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="opportunities_skills"
              source="opportunitiesskill.id"
              reference="OpportunitiesSkill"
            >
              <TextField source={OPPORTUNITIESSKILL_TITLE_FIELD} />
            </ReferenceField>
            <TextField
              label="Required_close_date"
              source="Required_close_date"
            />
            <TextField label="Status" source="Status" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
      </SimpleShowLayout>
    </Show>
  );
};
