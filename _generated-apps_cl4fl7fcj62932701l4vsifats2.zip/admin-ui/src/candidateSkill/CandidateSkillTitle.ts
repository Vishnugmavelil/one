import { CandidateSkill as TCandidateSkill } from "../api/candidateSkill/CandidateSkill";

export const CANDIDATESKILL_TITLE_FIELD = "id";

export const CandidateSkillTitle = (record: TCandidateSkill): string => {
  return record.id || record.id;
};
