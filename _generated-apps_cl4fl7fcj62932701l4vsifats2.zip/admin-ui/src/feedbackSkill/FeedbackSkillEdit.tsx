import * as React from "react";
import {
  Edit,
  SimpleForm,
  EditProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { InterviewFeedbackTitle } from "../interviewFeedback/InterviewFeedbackTitle";
import { SkillSetTitle } from "../skillSet/SkillSetTitle";

export const FeedbackSkillEdit = (props: EditProps): React.ReactElement => {
  return (
    <Edit {...props}>
      <SimpleForm>
        <ReferenceInput
          source="interviewfeedback.id"
          reference="InterviewFeedback"
          label="feedback_id"
        >
          <SelectInput optionText={InterviewFeedbackTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="skillset.id"
          reference="SkillSet"
          label="skill_id"
        >
          <SelectInput optionText={SkillSetTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Edit>
  );
};
