import { FeedbackSkill as TFeedbackSkill } from "../api/feedbackSkill/FeedbackSkill";

export const FEEDBACKSKILL_TITLE_FIELD = "id";

export const FeedbackSkillTitle = (record: TFeedbackSkill): string => {
  return record.id || record.id;
};
