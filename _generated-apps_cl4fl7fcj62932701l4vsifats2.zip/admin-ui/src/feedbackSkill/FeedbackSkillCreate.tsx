import * as React from "react";
import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { InterviewFeedbackTitle } from "../interviewFeedback/InterviewFeedbackTitle";
import { SkillSetTitle } from "../skillSet/SkillSetTitle";

export const FeedbackSkillCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="interviewfeedback.id"
          reference="InterviewFeedback"
          label="feedback_id"
        >
          <SelectInput optionText={InterviewFeedbackTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="skillset.id"
          reference="SkillSet"
          label="skill_id"
        >
          <SelectInput optionText={SkillSetTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Create>
  );
};
