import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type CandidateSkillUpdateInput = {
  candidateId?: CandidateWhereUniqueInput;
  skill_id?: SkillSetWhereUniqueInput;
};
