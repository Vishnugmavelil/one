import { FeedbackSkillWhereUniqueInput } from "./FeedbackSkillWhereUniqueInput";

export type FeedbackSkillFindUniqueArgs = {
  where: FeedbackSkillWhereUniqueInput;
};
