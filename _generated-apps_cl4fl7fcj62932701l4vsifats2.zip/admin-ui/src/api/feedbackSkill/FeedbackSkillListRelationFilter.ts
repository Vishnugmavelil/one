import { FeedbackSkillWhereInput } from "./FeedbackSkillWhereInput";

export type FeedbackSkillListRelationFilter = {
  every?: FeedbackSkillWhereInput;
  some?: FeedbackSkillWhereInput;
  none?: FeedbackSkillWhereInput;
};
