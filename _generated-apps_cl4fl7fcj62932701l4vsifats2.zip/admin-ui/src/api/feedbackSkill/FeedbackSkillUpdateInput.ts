import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";
import { SkillSetWhereUniqueInput } from "../skillSet/SkillSetWhereUniqueInput";

export type FeedbackSkillUpdateInput = {
  feedbackId?: InterviewFeedbackWhereUniqueInput;
  skillId?: SkillSetWhereUniqueInput;
};
