export type InterviewWhereUniqueInput = {
  id: string;
};
