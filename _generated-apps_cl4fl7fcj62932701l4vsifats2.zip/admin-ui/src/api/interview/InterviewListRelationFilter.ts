import { InterviewWhereInput } from "./InterviewWhereInput";

export type InterviewListRelationFilter = {
  every?: InterviewWhereInput;
  some?: InterviewWhereInput;
  none?: InterviewWhereInput;
};
