import { SortOrder } from "../../util/SortOrder";

export type InterviewOrderByInput = {
  assigned_hrId?: SortOrder;
  assigned_recruiterId?: SortOrder;
  candidateId?: SortOrder;
  createdAt?: SortOrder;
  date?: SortOrder;
  id?: SortOrder;
  interviewerId?: SortOrder;
  interview_feedbackId?: SortOrder;
  level?: SortOrder;
  updatedAt?: SortOrder;
};
