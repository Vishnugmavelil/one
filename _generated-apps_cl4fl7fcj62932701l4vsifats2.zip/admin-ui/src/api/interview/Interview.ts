import { Employee } from "../employee/Employee";
import { Candidate } from "../candidate/Candidate";

export type Interview = {
  assigned_hr?: Employee;
  assigned_recruiter?: Employee;
  candidate?: Candidate;
  createdAt: Date;
  date: Date;
  id: string;
  interviewer?: Employee;
  interview_feedback?: Candidate;
  level: string;
  updatedAt: Date;
};
