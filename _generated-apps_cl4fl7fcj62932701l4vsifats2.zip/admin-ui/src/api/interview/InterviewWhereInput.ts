import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { DateTimeFilter } from "../../util/DateTimeFilter";
import { StringFilter } from "../../util/StringFilter";

export type InterviewWhereInput = {
  assigned_hr?: EmployeeWhereUniqueInput;
  assigned_recruiter?: EmployeeWhereUniqueInput;
  candidate?: CandidateWhereUniqueInput;
  date?: DateTimeFilter;
  id?: StringFilter;
  interviewer?: EmployeeWhereUniqueInput;
  interview_feedback?: CandidateWhereUniqueInput;
  level?: StringFilter;
};
