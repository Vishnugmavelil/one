import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";

export type CommunityWhereInput = {
  communityId?: OpportunityWhereUniqueInput;
  description?: StringNullableFilter;
  employees?: EmployeeWhereUniqueInput;
  id?: StringFilter;
  name?: StringFilter;
};
