import { CommunityWhereUniqueInput } from "./CommunityWhereUniqueInput";

export type CommunityFindUniqueArgs = {
  where: CommunityWhereUniqueInput;
};
