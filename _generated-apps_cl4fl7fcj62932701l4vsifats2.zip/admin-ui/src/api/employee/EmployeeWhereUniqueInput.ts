export type EmployeeWhereUniqueInput = {
  id: string;
};
