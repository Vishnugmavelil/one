import { OpportunityWhereUniqueInput } from "../opportunity/OpportunityWhereUniqueInput";

export type OpportunityCreateNestedManyWithoutEmployeesInput = {
  connect?: Array<OpportunityWhereUniqueInput>;
};
