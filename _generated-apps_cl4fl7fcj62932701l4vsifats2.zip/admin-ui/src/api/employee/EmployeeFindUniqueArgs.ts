import { EmployeeWhereUniqueInput } from "./EmployeeWhereUniqueInput";

export type EmployeeFindUniqueArgs = {
  where: EmployeeWhereUniqueInput;
};
