import { OpportunitiesSkillWhereUniqueInput } from "./OpportunitiesSkillWhereUniqueInput";

export type DeleteOpportunitiesSkillArgs = {
  where: OpportunitiesSkillWhereUniqueInput;
};
