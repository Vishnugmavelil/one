import { OpportunitiesSkillCreateInput } from "./OpportunitiesSkillCreateInput";

export type CreateOpportunitiesSkillArgs = {
  data: OpportunitiesSkillCreateInput;
};
