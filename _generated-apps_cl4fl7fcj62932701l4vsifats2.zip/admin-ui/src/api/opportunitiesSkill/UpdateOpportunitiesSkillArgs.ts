import { OpportunitiesSkillWhereUniqueInput } from "./OpportunitiesSkillWhereUniqueInput";
import { OpportunitiesSkillUpdateInput } from "./OpportunitiesSkillUpdateInput";

export type UpdateOpportunitiesSkillArgs = {
  where: OpportunitiesSkillWhereUniqueInput;
  data: OpportunitiesSkillUpdateInput;
};
