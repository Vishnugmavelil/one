import { Community } from "../community/Community";
import { Employee } from "../employee/Employee";
import { OpportunitiesSkill } from "../opportunitiesSkill/OpportunitiesSkill";

export type Opportunity = {
  AssignedCommunity?: Community;
  ClaimedPerson?: Employee | null;
  createdAt: Date;
  Experience_required: number;
  firm: string;
  id: string;
  mappedPerson?: Employee | null;
  opportunitiesSkills?: OpportunitiesSkill;
  Required_close_date: Date;
  Status: string | null;
  updatedAt: Date;
};
