export type CandidateWhereUniqueInput = {
  id: string;
};
