import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";

export type CandidateUpdateManyWithoutCandidatesInput = {
  connect?: Array<CandidateWhereUniqueInput>;
  disconnect?: Array<CandidateWhereUniqueInput>;
  set?: Array<CandidateWhereUniqueInput>;
};
