import { CandidateWhereUniqueInput } from "./CandidateWhereUniqueInput";

export type CandidateCreateNestedManyWithoutCandidatesInput = {
  connect?: Array<CandidateWhereUniqueInput>;
};
