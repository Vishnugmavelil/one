import { CandidateSkillWhereUniqueInput } from "../candidateSkill/CandidateSkillWhereUniqueInput";
import { FeedbackSkillWhereUniqueInput } from "../feedbackSkill/FeedbackSkillWhereUniqueInput";
import { OpportunitiesSkillWhereUniqueInput } from "../opportunitiesSkill/OpportunitiesSkillWhereUniqueInput";

export type SkillSetUpdateInput = {
  candidateSkills?: CandidateSkillWhereUniqueInput;
  comments?: string | null;
  expertise_level?: string;
  feedbackSkills?: FeedbackSkillWhereUniqueInput;
  opportunitiesSkills?: OpportunitiesSkillWhereUniqueInput;
  skill_name?: string;
};
