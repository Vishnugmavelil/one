import { CandidateSkill } from "../candidateSkill/CandidateSkill";
import { FeedbackSkill } from "../feedbackSkill/FeedbackSkill";
import { OpportunitiesSkill } from "../opportunitiesSkill/OpportunitiesSkill";

export type SkillSet = {
  candidateSkills?: CandidateSkill;
  comments: string | null;
  createdAt: Date;
  expertise_level: string;
  feedbackSkills?: FeedbackSkill;
  id: string;
  opportunitiesSkills?: OpportunitiesSkill;
  skill_name: string;
  updatedAt: Date;
};
