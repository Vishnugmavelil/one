import { InterviewFeedbackCreateInput } from "./InterviewFeedbackCreateInput";

export type CreateInterviewFeedbackArgs = {
  data: InterviewFeedbackCreateInput;
};
