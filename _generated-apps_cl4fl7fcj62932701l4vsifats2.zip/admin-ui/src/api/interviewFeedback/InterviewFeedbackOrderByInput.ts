import { SortOrder } from "../../util/SortOrder";

export type InterviewFeedbackOrderByInput = {
  candidateFeedbacksId?: SortOrder;
  createdAt?: SortOrder;
  date?: SortOrder;
  feedback?: SortOrder;
  feedbackSkillsId?: SortOrder;
  id?: SortOrder;
  interviewerId?: SortOrder;
  updatedAt?: SortOrder;
};
