import { InterviewFeedbackWhereUniqueInput } from "./InterviewFeedbackWhereUniqueInput";

export type DeleteInterviewFeedbackArgs = {
  where: InterviewFeedbackWhereUniqueInput;
};
