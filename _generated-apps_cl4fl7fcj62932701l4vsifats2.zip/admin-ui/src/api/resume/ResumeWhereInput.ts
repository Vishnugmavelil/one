import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { StringNullableFilter } from "../../util/StringNullableFilter";
import { StringFilter } from "../../util/StringFilter";
import { EmployeeResumeWhereUniqueInput } from "../employeeResume/EmployeeResumeWhereUniqueInput";

export type ResumeWhereInput = {
  candidates?: CandidateWhereUniqueInput;
  comment?: StringNullableFilter;
  document?: StringFilter;
  employeeResumes?: EmployeeResumeWhereUniqueInput;
  id?: StringFilter;
};
