import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { EmployeeResumeWhereUniqueInput } from "../employeeResume/EmployeeResumeWhereUniqueInput";

export type ResumeCreateInput = {
  candidates?: CandidateWhereUniqueInput;
  comment?: string | null;
  document: string;
  employeeResumes?: EmployeeResumeWhereUniqueInput;
};
