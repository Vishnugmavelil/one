import { CandidateFeedbackWhereInput } from "./CandidateFeedbackWhereInput";

export type CandidateFeedbackListRelationFilter = {
  every?: CandidateFeedbackWhereInput;
  some?: CandidateFeedbackWhereInput;
  none?: CandidateFeedbackWhereInput;
};
