import { CandidateWhereUniqueInput } from "../candidate/CandidateWhereUniqueInput";
import { InterviewFeedbackWhereUniqueInput } from "../interviewFeedback/InterviewFeedbackWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";

export type CandidateFeedbackWhereInput = {
  candidate_id?: CandidateWhereUniqueInput;
  feedback_id?: InterviewFeedbackWhereUniqueInput;
  id?: StringFilter;
};
