import { CandidateFeedbackCreateInput } from "./CandidateFeedbackCreateInput";

export type CreateCandidateFeedbackArgs = {
  data: CandidateFeedbackCreateInput;
};
