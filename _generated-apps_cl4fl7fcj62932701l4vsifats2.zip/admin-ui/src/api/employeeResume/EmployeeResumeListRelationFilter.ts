import { EmployeeResumeWhereInput } from "./EmployeeResumeWhereInput";

export type EmployeeResumeListRelationFilter = {
  every?: EmployeeResumeWhereInput;
  some?: EmployeeResumeWhereInput;
  none?: EmployeeResumeWhereInput;
};
