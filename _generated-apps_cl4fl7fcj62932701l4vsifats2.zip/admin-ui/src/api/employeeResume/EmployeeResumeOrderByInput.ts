import { SortOrder } from "../../util/SortOrder";

export type EmployeeResumeOrderByInput = {
  createdAt?: SortOrder;
  employeeIdId?: SortOrder;
  id?: SortOrder;
  resumeIdId?: SortOrder;
  updatedAt?: SortOrder;
};
