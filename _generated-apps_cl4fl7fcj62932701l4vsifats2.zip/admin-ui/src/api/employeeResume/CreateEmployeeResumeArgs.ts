import { EmployeeResumeCreateInput } from "./EmployeeResumeCreateInput";

export type CreateEmployeeResumeArgs = {
  data: EmployeeResumeCreateInput;
};
