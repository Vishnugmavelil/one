import { Employee } from "../employee/Employee";
import { Resume } from "../resume/Resume";

export type EmployeeResume = {
  createdAt: Date;
  employeeId?: Employee;
  id: string;
  resumeId?: Resume;
  updatedAt: Date;
};
