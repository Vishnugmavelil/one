import { EmployeeWhereUniqueInput } from "../employee/EmployeeWhereUniqueInput";
import { ResumeWhereUniqueInput } from "../resume/ResumeWhereUniqueInput";

export type EmployeeResumeCreateInput = {
  employeeId: EmployeeWhereUniqueInput;
  resumeId: ResumeWhereUniqueInput;
};
