import * as React from "react";

import {
  List,
  Datagrid,
  ListProps,
  TextField,
  ReferenceField,
  DateField,
  BooleanField,
} from "react-admin";

import Pagination from "../Components/Pagination";
import { CANDIDATEFEEDBACK_TITLE_FIELD } from "../candidateFeedback/CandidateFeedbackTitle";
import { CANDIDATESKILL_TITLE_FIELD } from "../candidateSkill/CandidateSkillTitle";
import { CANDIDATE_TITLE_FIELD } from "./CandidateTitle";
import { INTERVIEW_TITLE_FIELD } from "../interview/InterviewTitle";
import { RESUME_TITLE_FIELD } from "../resume/ResumeTitle";

export const CandidateList = (props: ListProps): React.ReactElement => {
  return (
    <List
      {...props}
      bulkActionButtons={false}
      title={"candidates"}
      perPage={50}
      pagination={<Pagination />}
    >
      <Datagrid rowClick="show">
        <TextField label="additional_comments" source="additional_comments" />
        <ReferenceField
          label="candidate_feedbacks"
          source="candidatefeedback.id"
          reference="CandidateFeedback"
        >
          <TextField source={CANDIDATEFEEDBACK_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="candidate_skill"
          source="candidateskill.id"
          reference="CandidateSkill"
        >
          <TextField source={CANDIDATESKILL_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="candidates_notice_period"
          source="candidate.id"
          reference="Candidate"
        >
          <TextField source={CANDIDATE_TITLE_FIELD} />
        </ReferenceField>
        <DateField source="createdAt" label="Created At" />
        <TextField label="current_firm" source="current_firm" />
        <TextField label="ID" source="id" />
        <ReferenceField
          label="interviews"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <BooleanField
          label="is_on_notice_period"
          source="is_on_notice_period"
        />
        <TextField label="last_workingday" source="last_workingday" />
        <ReferenceField
          label="Name"
          source="candidate.id"
          reference="Candidate"
        >
          <TextField source={CANDIDATE_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField label="resume" source="resume.id" reference="Resume">
          <TextField source={RESUME_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="skill_set" source="skill_Set" />
        <DateField source="updatedAt" label="Updated At" />
      </Datagrid>
    </List>
  );
};
