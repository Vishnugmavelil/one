import * as React from "react";

import {
  Create,
  SimpleForm,
  CreateProps,
  TextInput,
  ReferenceInput,
  SelectInput,
  ReferenceArrayInput,
  SelectArrayInput,
  BooleanInput,
  DateInput,
} from "react-admin";

import { CandidateFeedbackTitle } from "../candidateFeedback/CandidateFeedbackTitle";
import { CandidateTitle } from "./CandidateTitle";
import { CandidateSkillTitle } from "../candidateSkill/CandidateSkillTitle";
import { InterviewTitle } from "../interview/InterviewTitle";
import { ResumeTitle } from "../resume/ResumeTitle";

export const CandidateCreate = (props: CreateProps): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <TextInput
          label="additional_comments"
          multiline
          source="additional_comments"
        />
        <ReferenceInput
          source="candidatefeedback.id"
          reference="CandidateFeedback"
          label="candidate_feedbacks"
        >
          <SelectInput optionText={CandidateFeedbackTitle} />
        </ReferenceInput>
        <ReferenceArrayInput
          source="candidatesEmail"
          reference="Candidate"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={CandidateTitle} />
        </ReferenceArrayInput>
        <ReferenceInput
          source="candidateskill.id"
          reference="CandidateSkill"
          label="candidate_skill"
        >
          <SelectInput optionText={CandidateSkillTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="candidate.id"
          reference="Candidate"
          label="candidates_notice_period"
        >
          <SelectInput optionText={CandidateTitle} />
        </ReferenceInput>
        <TextInput label="current_firm" source="current_firm" />
        <ReferenceArrayInput
          source="current_status"
          reference="Candidate"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={CandidateTitle} />
        </ReferenceArrayInput>
        <ReferenceArrayInput
          source="interviewFeedback"
          reference="Interview"
          parse={(value: any) => value && value.map((v: any) => ({ id: v }))}
          format={(value: any) => value && value.map((v: any) => v.id)}
        >
          <SelectArrayInput optionText={InterviewTitle} />
        </ReferenceArrayInput>
        <ReferenceInput
          source="interview.id"
          reference="Interview"
          label="interviews"
        >
          <SelectInput optionText={InterviewTitle} />
        </ReferenceInput>
        <BooleanInput
          label="is_on_notice_period"
          source="is_on_notice_period"
        />
        <DateInput label="last_workingday" source="last_workingday" />
        <ReferenceInput
          source="candidate.id"
          reference="Candidate"
          label="Name"
        >
          <SelectInput optionText={CandidateTitle} />
        </ReferenceInput>
        <ReferenceInput source="resume.id" reference="Resume" label="resume">
          <SelectInput optionText={ResumeTitle} />
        </ReferenceInput>
        <TextInput label="skill_set" source="skill_Set" />
      </SimpleForm>
    </Create>
  );
};
