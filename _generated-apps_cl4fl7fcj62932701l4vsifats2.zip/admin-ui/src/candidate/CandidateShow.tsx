import * as React from "react";

import {
  Show,
  SimpleShowLayout,
  ShowProps,
  TextField,
  ReferenceField,
  DateField,
  BooleanField,
  ReferenceManyField,
  Datagrid,
} from "react-admin";

import { CANDIDATEFEEDBACK_TITLE_FIELD } from "../candidateFeedback/CandidateFeedbackTitle";
import { CANDIDATESKILL_TITLE_FIELD } from "../candidateSkill/CandidateSkillTitle";
import { CANDIDATE_TITLE_FIELD } from "./CandidateTitle";
import { INTERVIEW_TITLE_FIELD } from "../interview/InterviewTitle";
import { RESUME_TITLE_FIELD } from "../resume/ResumeTitle";
import { EMPLOYEE_TITLE_FIELD } from "../employee/EmployeeTitle";

export const CandidateShow = (props: ShowProps): React.ReactElement => {
  return (
    <Show {...props}>
      <SimpleShowLayout>
        <TextField label="additional_comments" source="additional_comments" />
        <ReferenceField
          label="candidate_feedbacks"
          source="candidatefeedback.id"
          reference="CandidateFeedback"
        >
          <TextField source={CANDIDATEFEEDBACK_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="candidate_skill"
          source="candidateskill.id"
          reference="CandidateSkill"
        >
          <TextField source={CANDIDATESKILL_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField
          label="candidates_notice_period"
          source="candidate.id"
          reference="Candidate"
        >
          <TextField source={CANDIDATE_TITLE_FIELD} />
        </ReferenceField>
        <DateField source="createdAt" label="Created At" />
        <TextField label="current_firm" source="current_firm" />
        <TextField label="ID" source="id" />
        <ReferenceField
          label="interviews"
          source="interview.id"
          reference="Interview"
        >
          <TextField source={INTERVIEW_TITLE_FIELD} />
        </ReferenceField>
        <BooleanField
          label="is_on_notice_period"
          source="is_on_notice_period"
        />
        <TextField label="last_workingday" source="last_workingday" />
        <ReferenceField
          label="Name"
          source="candidate.id"
          reference="Candidate"
        >
          <TextField source={CANDIDATE_TITLE_FIELD} />
        </ReferenceField>
        <ReferenceField label="resume" source="resume.id" reference="Resume">
          <TextField source={RESUME_TITLE_FIELD} />
        </ReferenceField>
        <TextField label="skill_set" source="skill_Set" />
        <DateField source="updatedAt" label="Updated At" />
        <ReferenceManyField
          reference="Candidate"
          target="CandidateId"
          label="candidates"
        >
          <Datagrid rowClick="show">
            <TextField
              label="additional_comments"
              source="additional_comments"
            />
            <ReferenceField
              label="candidate_feedbacks"
              source="candidatefeedback.id"
              reference="CandidateFeedback"
            >
              <TextField source={CANDIDATEFEEDBACK_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="candidate_skill"
              source="candidateskill.id"
              reference="CandidateSkill"
            >
              <TextField source={CANDIDATESKILL_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="candidates_notice_period"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField label="current_firm" source="current_firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="interviews"
              source="interview.id"
              reference="Interview"
            >
              <TextField source={INTERVIEW_TITLE_FIELD} />
            </ReferenceField>
            <BooleanField
              label="is_on_notice_period"
              source="is_on_notice_period"
            />
            <TextField label="last_workingday" source="last_workingday" />
            <ReferenceField
              label="Name"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="resume"
              source="resume.id"
              reference="Resume"
            >
              <TextField source={RESUME_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="skill_set" source="skill_Set" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
        <ReferenceManyField
          reference="Candidate"
          target="CandidateId"
          label="candidates"
        >
          <Datagrid rowClick="show">
            <TextField
              label="additional_comments"
              source="additional_comments"
            />
            <ReferenceField
              label="candidate_feedbacks"
              source="candidatefeedback.id"
              reference="CandidateFeedback"
            >
              <TextField source={CANDIDATEFEEDBACK_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="candidate_skill"
              source="candidateskill.id"
              reference="CandidateSkill"
            >
              <TextField source={CANDIDATESKILL_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="candidates_notice_period"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField label="current_firm" source="current_firm" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="interviews"
              source="interview.id"
              reference="Interview"
            >
              <TextField source={INTERVIEW_TITLE_FIELD} />
            </ReferenceField>
            <BooleanField
              label="is_on_notice_period"
              source="is_on_notice_period"
            />
            <TextField label="last_workingday" source="last_workingday" />
            <ReferenceField
              label="Name"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="resume"
              source="resume.id"
              reference="Resume"
            >
              <TextField source={RESUME_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="skill_set" source="skill_Set" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
        <ReferenceManyField
          reference="Interview"
          target="CandidateId"
          label="interviews"
        >
          <Datagrid rowClick="show">
            <ReferenceField
              label="assigned_hr"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="assigned_recruiter"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="candidate"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <DateField source="createdAt" label="Created At" />
            <TextField label="date" source="date" />
            <TextField label="ID" source="id" />
            <ReferenceField
              label="interviewer"
              source="employee.id"
              reference="Employee"
            >
              <TextField source={EMPLOYEE_TITLE_FIELD} />
            </ReferenceField>
            <ReferenceField
              label="interview_feedback"
              source="candidate.id"
              reference="Candidate"
            >
              <TextField source={CANDIDATE_TITLE_FIELD} />
            </ReferenceField>
            <TextField label="level" source="level" />
            <DateField source="updatedAt" label="Updated At" />
          </Datagrid>
        </ReferenceManyField>
      </SimpleShowLayout>
    </Show>
  );
};
