import React, { useEffect, useState } from "react";
import { Admin, DataProvider, Resource } from "react-admin";
import buildGraphQLProvider from "./data-provider/graphqlDataProvider";
import { theme } from "./theme/theme";
import Login from "./Login";
import "./App.scss";
import Dashboard from "./pages/Dashboard";
import { UserList } from "./user/UserList";
import { UserCreate } from "./user/UserCreate";
import { UserEdit } from "./user/UserEdit";
import { UserShow } from "./user/UserShow";
import { CommunityList } from "./community/CommunityList";
import { CommunityCreate } from "./community/CommunityCreate";
import { CommunityEdit } from "./community/CommunityEdit";
import { CommunityShow } from "./community/CommunityShow";
import { CandidateList } from "./candidate/CandidateList";
import { CandidateCreate } from "./candidate/CandidateCreate";
import { CandidateEdit } from "./candidate/CandidateEdit";
import { CandidateShow } from "./candidate/CandidateShow";
import { ResumeList } from "./resume/ResumeList";
import { ResumeCreate } from "./resume/ResumeCreate";
import { ResumeEdit } from "./resume/ResumeEdit";
import { ResumeShow } from "./resume/ResumeShow";
import { SkillSetList } from "./skillSet/SkillSetList";
import { SkillSetCreate } from "./skillSet/SkillSetCreate";
import { SkillSetEdit } from "./skillSet/SkillSetEdit";
import { SkillSetShow } from "./skillSet/SkillSetShow";
import { CandidateFeedbackList } from "./candidateFeedback/CandidateFeedbackList";
import { CandidateFeedbackCreate } from "./candidateFeedback/CandidateFeedbackCreate";
import { CandidateFeedbackEdit } from "./candidateFeedback/CandidateFeedbackEdit";
import { CandidateFeedbackShow } from "./candidateFeedback/CandidateFeedbackShow";
import { EmployeeList } from "./employee/EmployeeList";
import { EmployeeCreate } from "./employee/EmployeeCreate";
import { EmployeeEdit } from "./employee/EmployeeEdit";
import { EmployeeShow } from "./employee/EmployeeShow";
import { OpportunityList } from "./opportunity/OpportunityList";
import { OpportunityCreate } from "./opportunity/OpportunityCreate";
import { OpportunityEdit } from "./opportunity/OpportunityEdit";
import { OpportunityShow } from "./opportunity/OpportunityShow";
import { EmployeeResumeList } from "./employeeResume/EmployeeResumeList";
import { EmployeeResumeCreate } from "./employeeResume/EmployeeResumeCreate";
import { EmployeeResumeEdit } from "./employeeResume/EmployeeResumeEdit";
import { EmployeeResumeShow } from "./employeeResume/EmployeeResumeShow";
import { OpportunitiesSkillList } from "./opportunitiesSkill/OpportunitiesSkillList";
import { OpportunitiesSkillCreate } from "./opportunitiesSkill/OpportunitiesSkillCreate";
import { OpportunitiesSkillEdit } from "./opportunitiesSkill/OpportunitiesSkillEdit";
import { OpportunitiesSkillShow } from "./opportunitiesSkill/OpportunitiesSkillShow";
import { InterviewList } from "./interview/InterviewList";
import { InterviewCreate } from "./interview/InterviewCreate";
import { InterviewEdit } from "./interview/InterviewEdit";
import { InterviewShow } from "./interview/InterviewShow";
import { CandidateSkillList } from "./candidateSkill/CandidateSkillList";
import { CandidateSkillCreate } from "./candidateSkill/CandidateSkillCreate";
import { CandidateSkillEdit } from "./candidateSkill/CandidateSkillEdit";
import { CandidateSkillShow } from "./candidateSkill/CandidateSkillShow";
import { InterviewFeedbackList } from "./interviewFeedback/InterviewFeedbackList";
import { InterviewFeedbackCreate } from "./interviewFeedback/InterviewFeedbackCreate";
import { InterviewFeedbackEdit } from "./interviewFeedback/InterviewFeedbackEdit";
import { InterviewFeedbackShow } from "./interviewFeedback/InterviewFeedbackShow";
import { FeedbackSkillList } from "./feedbackSkill/FeedbackSkillList";
import { FeedbackSkillCreate } from "./feedbackSkill/FeedbackSkillCreate";
import { FeedbackSkillEdit } from "./feedbackSkill/FeedbackSkillEdit";
import { FeedbackSkillShow } from "./feedbackSkill/FeedbackSkillShow";
import { jwtAuthProvider } from "./auth-provider/ra-auth-jwt";

const App = (): React.ReactElement => {
  const [dataProvider, setDataProvider] = useState<DataProvider | null>(null);
  useEffect(() => {
    buildGraphQLProvider
      .then((provider: any) => {
        setDataProvider(() => provider);
      })
      .catch((error: any) => {
        console.log(error);
      });
  }, []);
  if (!dataProvider) {
    return <div>Loading</div>;
  }
  return (
    <div className="App">
      <Admin
        title={"One-place"}
        dataProvider={dataProvider}
        authProvider={jwtAuthProvider}
        theme={theme}
        dashboard={Dashboard}
        loginPage={Login}
      >
        <Resource
          name="User"
          list={UserList}
          edit={UserEdit}
          create={UserCreate}
          show={UserShow}
        />
        <Resource
          name="Community"
          list={CommunityList}
          edit={CommunityEdit}
          create={CommunityCreate}
          show={CommunityShow}
        />
        <Resource
          name="Candidate"
          list={CandidateList}
          edit={CandidateEdit}
          create={CandidateCreate}
          show={CandidateShow}
        />
        <Resource
          name="Resume"
          list={ResumeList}
          edit={ResumeEdit}
          create={ResumeCreate}
          show={ResumeShow}
        />
        <Resource
          name="SkillSet"
          list={SkillSetList}
          edit={SkillSetEdit}
          create={SkillSetCreate}
          show={SkillSetShow}
        />
        <Resource
          name="CandidateFeedback"
          list={CandidateFeedbackList}
          edit={CandidateFeedbackEdit}
          create={CandidateFeedbackCreate}
          show={CandidateFeedbackShow}
        />
        <Resource
          name="Employee"
          list={EmployeeList}
          edit={EmployeeEdit}
          create={EmployeeCreate}
          show={EmployeeShow}
        />
        <Resource
          name="Opportunity"
          list={OpportunityList}
          edit={OpportunityEdit}
          create={OpportunityCreate}
          show={OpportunityShow}
        />
        <Resource
          name="EmployeeResume"
          list={EmployeeResumeList}
          edit={EmployeeResumeEdit}
          create={EmployeeResumeCreate}
          show={EmployeeResumeShow}
        />
        <Resource
          name="OpportunitiesSkill"
          list={OpportunitiesSkillList}
          edit={OpportunitiesSkillEdit}
          create={OpportunitiesSkillCreate}
          show={OpportunitiesSkillShow}
        />
        <Resource
          name="Interview"
          list={InterviewList}
          edit={InterviewEdit}
          create={InterviewCreate}
          show={InterviewShow}
        />
        <Resource
          name="CandidateSkill"
          list={CandidateSkillList}
          edit={CandidateSkillEdit}
          create={CandidateSkillCreate}
          show={CandidateSkillShow}
        />
        <Resource
          name="InterviewFeedback"
          list={InterviewFeedbackList}
          edit={InterviewFeedbackEdit}
          create={InterviewFeedbackCreate}
          show={InterviewFeedbackShow}
        />
        <Resource
          name="FeedbackSkill"
          list={FeedbackSkillList}
          edit={FeedbackSkillEdit}
          create={FeedbackSkillCreate}
          show={FeedbackSkillShow}
        />
      </Admin>
    </div>
  );
};

export default App;
