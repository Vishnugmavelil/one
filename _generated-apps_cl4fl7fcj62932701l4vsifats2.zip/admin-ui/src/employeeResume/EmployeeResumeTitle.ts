import { EmployeeResume as TEmployeeResume } from "../api/employeeResume/EmployeeResume";

export const EMPLOYEERESUME_TITLE_FIELD = "id";

export const EmployeeResumeTitle = (record: TEmployeeResume): string => {
  return record.id || record.id;
};
