import * as React from "react";
import {
  Create,
  SimpleForm,
  CreateProps,
  ReferenceInput,
  SelectInput,
} from "react-admin";
import { OpportunityTitle } from "../opportunity/OpportunityTitle";
import { SkillSetTitle } from "../skillSet/SkillSetTitle";

export const OpportunitiesSkillCreate = (
  props: CreateProps
): React.ReactElement => {
  return (
    <Create {...props}>
      <SimpleForm>
        <ReferenceInput
          source="opportunity.id"
          reference="Opportunity"
          label="opportunities_id"
        >
          <SelectInput optionText={OpportunityTitle} />
        </ReferenceInput>
        <ReferenceInput
          source="skillset.id"
          reference="SkillSet"
          label="skill_id"
        >
          <SelectInput optionText={SkillSetTitle} />
        </ReferenceInput>
      </SimpleForm>
    </Create>
  );
};
