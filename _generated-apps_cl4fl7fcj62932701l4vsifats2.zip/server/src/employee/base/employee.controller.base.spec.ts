import { Test } from "@nestjs/testing";
import { INestApplication, HttpStatus, ExecutionContext } from "@nestjs/common";
import request from "supertest";
import { MorganModule } from "nest-morgan";
import { ACGuard } from "nest-access-control";
import { DefaultAuthGuard } from "../../auth/defaultAuth.guard";
import { ACLModule } from "../../auth/acl.module";
import { EmployeeController } from "../employee.controller";
import { EmployeeService } from "../employee.service";

const nonExistingId = "nonExistingId";
const existingId = "existingId";
const CREATE_INPUT = {
  Aadhar: 42,
  Blood_Group: "exampleBloodGroup",
  career_start_date: new Date(),
  contactNumber: 42,
  createdAt: new Date(),
  date_of_joining: new Date(),
  dob: new Date(),
  email: "exampleEmail",
  Emergency_Contact_Number: 42,
  fw_experience: 42.42,
  gender: "exampleGender",
  id: "exampleId",
  name: "exampleName",
  Personal_Mail_ID: "examplePersonalMailId",
  total_experience: 42.42,
  updatedAt: new Date(),
};
const CREATE_RESULT = {
  Aadhar: 42,
  Blood_Group: "exampleBloodGroup",
  career_start_date: new Date(),
  contactNumber: 42,
  createdAt: new Date(),
  date_of_joining: new Date(),
  dob: new Date(),
  email: "exampleEmail",
  Emergency_Contact_Number: 42,
  fw_experience: 42.42,
  gender: "exampleGender",
  id: "exampleId",
  name: "exampleName",
  Personal_Mail_ID: "examplePersonalMailId",
  total_experience: 42.42,
  updatedAt: new Date(),
};
const FIND_MANY_RESULT = [
  {
    Aadhar: 42,
    Blood_Group: "exampleBloodGroup",
    career_start_date: new Date(),
    contactNumber: 42,
    createdAt: new Date(),
    date_of_joining: new Date(),
    dob: new Date(),
    email: "exampleEmail",
    Emergency_Contact_Number: 42,
    fw_experience: 42.42,
    gender: "exampleGender",
    id: "exampleId",
    name: "exampleName",
    Personal_Mail_ID: "examplePersonalMailId",
    total_experience: 42.42,
    updatedAt: new Date(),
  },
];
const FIND_ONE_RESULT = {
  Aadhar: 42,
  Blood_Group: "exampleBloodGroup",
  career_start_date: new Date(),
  contactNumber: 42,
  createdAt: new Date(),
  date_of_joining: new Date(),
  dob: new Date(),
  email: "exampleEmail",
  Emergency_Contact_Number: 42,
  fw_experience: 42.42,
  gender: "exampleGender",
  id: "exampleId",
  name: "exampleName",
  Personal_Mail_ID: "examplePersonalMailId",
  total_experience: 42.42,
  updatedAt: new Date(),
};

const service = {
  create() {
    return CREATE_RESULT;
  },
  findMany: () => FIND_MANY_RESULT,
  findOne: ({ where }: { where: { id: string } }) => {
    switch (where.id) {
      case existingId:
        return FIND_ONE_RESULT;
      case nonExistingId:
        return null;
    }
  },
};

const basicAuthGuard = {
  canActivate: (context: ExecutionContext) => {
    const argumentHost = context.switchToHttp();
    const request = argumentHost.getRequest();
    request.user = {
      roles: ["user"],
    };
    return true;
  },
};

const acGuard = {
  canActivate: () => {
    return true;
  },
};

describe("Employee", () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [
        {
          provide: EmployeeService,
          useValue: service,
        },
      ],
      controllers: [EmployeeController],
      imports: [MorganModule.forRoot(), ACLModule],
    })
      .overrideGuard(DefaultAuthGuard)
      .useValue(basicAuthGuard)
      .overrideGuard(ACGuard)
      .useValue(acGuard)
      .compile();

    app = moduleRef.createNestApplication();
    await app.init();
  });

  test("POST /employees", async () => {
    await request(app.getHttpServer())
      .post("/employees")
      .send(CREATE_INPUT)
      .expect(HttpStatus.CREATED)
      .expect({
        ...CREATE_RESULT,
        career_start_date: CREATE_RESULT.career_start_date.toISOString(),
        createdAt: CREATE_RESULT.createdAt.toISOString(),
        date_of_joining: CREATE_RESULT.date_of_joining.toISOString(),
        dob: CREATE_RESULT.dob.toISOString(),
        updatedAt: CREATE_RESULT.updatedAt.toISOString(),
      });
  });

  test("GET /employees", async () => {
    await request(app.getHttpServer())
      .get("/employees")
      .expect(HttpStatus.OK)
      .expect([
        {
          ...FIND_MANY_RESULT[0],
          career_start_date: FIND_MANY_RESULT[0].career_start_date.toISOString(),
          createdAt: FIND_MANY_RESULT[0].createdAt.toISOString(),
          date_of_joining: FIND_MANY_RESULT[0].date_of_joining.toISOString(),
          dob: FIND_MANY_RESULT[0].dob.toISOString(),
          updatedAt: FIND_MANY_RESULT[0].updatedAt.toISOString(),
        },
      ]);
  });

  test("GET /employees/:id non existing", async () => {
    await request(app.getHttpServer())
      .get(`${"/employees"}/${nonExistingId}`)
      .expect(HttpStatus.NOT_FOUND)
      .expect({
        statusCode: HttpStatus.NOT_FOUND,
        message: `No resource was found for {"${"id"}":"${nonExistingId}"}`,
        error: "Not Found",
      });
  });

  test("GET /employees/:id existing", async () => {
    await request(app.getHttpServer())
      .get(`${"/employees"}/${existingId}`)
      .expect(HttpStatus.OK)
      .expect({
        ...FIND_ONE_RESULT,
        career_start_date: FIND_ONE_RESULT.career_start_date.toISOString(),
        createdAt: FIND_ONE_RESULT.createdAt.toISOString(),
        date_of_joining: FIND_ONE_RESULT.date_of_joining.toISOString(),
        dob: FIND_ONE_RESULT.dob.toISOString(),
        updatedAt: FIND_ONE_RESULT.updatedAt.toISOString(),
      });
  });

  afterAll(async () => {
    await app.close();
  });
});
