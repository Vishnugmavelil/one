import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { CandidateFeedbackServiceBase } from "./base/candidateFeedback.service.base";

@Injectable()
export class CandidateFeedbackService extends CandidateFeedbackServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
