import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as nestAccessControl from "nest-access-control";
import { GqlDefaultAuthGuard } from "../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../auth/gqlAC.guard";
import { FeedbackSkillResolverBase } from "./base/feedbackSkill.resolver.base";
import { FeedbackSkill } from "./base/FeedbackSkill";
import { FeedbackSkillService } from "./feedbackSkill.service";

@graphql.Resolver(() => FeedbackSkill)
@common.UseGuards(GqlDefaultAuthGuard, gqlACGuard.GqlACGuard)
export class FeedbackSkillResolver extends FeedbackSkillResolverBase {
  constructor(
    protected readonly service: FeedbackSkillService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
