import { Module } from "@nestjs/common";
import { FeedbackSkillModuleBase } from "./base/feedbackSkill.module.base";
import { FeedbackSkillService } from "./feedbackSkill.service";
import { FeedbackSkillController } from "./feedbackSkill.controller";
import { FeedbackSkillResolver } from "./feedbackSkill.resolver";

@Module({
  imports: [FeedbackSkillModuleBase],
  controllers: [FeedbackSkillController],
  providers: [FeedbackSkillService, FeedbackSkillResolver],
  exports: [FeedbackSkillService],
})
export class FeedbackSkillModule {}
