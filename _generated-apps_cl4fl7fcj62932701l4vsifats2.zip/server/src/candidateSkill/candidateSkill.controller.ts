import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { CandidateSkillService } from "./candidateSkill.service";
import { CandidateSkillControllerBase } from "./base/candidateSkill.controller.base";

@swagger.ApiTags("candidateSkills")
@common.Controller("candidateSkills")
export class CandidateSkillController extends CandidateSkillControllerBase {
  constructor(
    protected readonly service: CandidateSkillService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
