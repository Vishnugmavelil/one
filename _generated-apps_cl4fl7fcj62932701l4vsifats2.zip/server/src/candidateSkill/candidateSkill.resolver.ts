import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as nestAccessControl from "nest-access-control";
import { GqlDefaultAuthGuard } from "../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../auth/gqlAC.guard";
import { CandidateSkillResolverBase } from "./base/candidateSkill.resolver.base";
import { CandidateSkill } from "./base/CandidateSkill";
import { CandidateSkillService } from "./candidateSkill.service";

@graphql.Resolver(() => CandidateSkill)
@common.UseGuards(GqlDefaultAuthGuard, gqlACGuard.GqlACGuard)
export class CandidateSkillResolver extends CandidateSkillResolverBase {
  constructor(
    protected readonly service: CandidateSkillService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
