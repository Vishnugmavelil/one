import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { EmployeeResumeServiceBase } from "./base/employeeResume.service.base";

@Injectable()
export class EmployeeResumeService extends EmployeeResumeServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
