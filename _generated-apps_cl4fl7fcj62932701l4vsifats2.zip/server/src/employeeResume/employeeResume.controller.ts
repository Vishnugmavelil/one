import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { EmployeeResumeService } from "./employeeResume.service";
import { EmployeeResumeControllerBase } from "./base/employeeResume.controller.base";

@swagger.ApiTags("employeeResumes")
@common.Controller("employeeResumes")
export class EmployeeResumeController extends EmployeeResumeControllerBase {
  constructor(
    protected readonly service: EmployeeResumeService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
